"""PythonAnywhere WSGI entrypoint for FitBuddy.

PythonAnywhere serves classic WSGI apps, while FitBuddy is a FastAPI (ASGI)
app. ``a2wsgi`` bridges the two. Configure this file as your WSGI application
file in the PythonAnywhere Web tab.

Expects the project to live at ~/fitbuddy and a secrets file at
~/fitbuddy/.env (see .env.example). The SQLite database is written to
~/fitbuddy/fitbuddy.db.
"""

import os
from pathlib import Path

import dotenv

PROJECT_DIR = Path.home() / "fitbuddy"

dotenv.load_dotenv(PROJECT_DIR / ".env")

os.environ.setdefault("DATABASE_URL", f"sqlite:///{PROJECT_DIR / 'fitbuddy.db'}")

from a2wsgi import ASGIMiddleware  # noqa: E402
from app.main import app  # noqa: E402

application = ASGIMiddleware(app)