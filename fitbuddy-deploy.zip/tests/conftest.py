"""Shared test fixtures.

Two rules make the rest of the suite simple:

1. Environment variables are set *before* ``app`` is imported, because
   ``get_settings`` is cached and the engine is created from it.
2. The AI layer is replaced at the point of use. ``plan_service`` calls
   ``workout.generate_plan`` through the module, so patching
   ``app.ai.workout`` is enough, but ``generate_tip`` is imported by name, so
   that one must be patched on ``app.services.plan_service``. Getting this
   wrong is the classic reason "the fake AI" appears to be ignored.
"""

from __future__ import annotations

import os
import re
import tempfile
from collections.abc import Iterator
from pathlib import Path

import pytest

_TMP_DIR = tempfile.TemporaryDirectory(prefix="fitbuddy-tests-")
_TEST_DB = Path(_TMP_DIR.name) / "test.db"

os.environ.update(
    {
        "APP_ENV": "test",
        "DATABASE_URL": f"sqlite:///{_TEST_DB}",
        "SECRET_KEY": "test-secret-key-not-used-in-production-0123456789",
        "GEMINI_API_KEY": "test-key",
        "GEMINI_TIMEOUT_SEC": "5",
        "RATE_LIMIT_PER_MIN": "120",
    }
)

from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy.orm import Session  # noqa: E402

from app.database import Base, get_engine, get_sessionmaker, reset_engine  # noqa: E402
from app.enums import Goal, Intensity, Role  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Plan, User  # noqa: E402
from app.schemas import (  # noqa: E402
    Exercise,
    PlanDay,
    ProfileInput,
    RegisterInput,
    Warmup,
    WorkoutPlan,
)
from app.security import use_fast_hashing  # noqa: E402
from app.services import plan_service, user_service  # noqa: E402

CSRF_RE = re.compile(r'name="csrf_token" value="([^"]+)"')
SESSION_USER_RE = re.compile(r'data-current-user="(\d+)"')


# --------------------------------------------------------------------------- #
# Fake AI payloads
# --------------------------------------------------------------------------- #
def fake_workout_plan(version: int = 1) -> WorkoutPlan:
    """A deterministic, schema-valid seven-day plan."""
    return WorkoutPlan(
        summary=f"A medium week of steady strength work (revision {version}).",
        days=[
            PlanDay(
                day=index,
                focus=f"Focus for day {index}",
                is_rest_day=index in (3, 7),
                warmup=Warmup(duration_min=8, items=["Arm circles", "Jumping jacks"]),
                exercises=(
                    []
                    if index in (3, 7)
                    else [
                        Exercise(name="Push-up", sets=3, reps="10-12", rest_sec=60),
                        Exercise(name="Bodyweight squat", sets=3, reps="12-15", rest_sec=75),
                    ]
                ),
                cooldown="Light stretching for five minutes.",
            )
            for index in range(1, 8)
        ],
        notes=["Progress the load before adding volume.", "Stop if you feel sharp pain."],
    )


@pytest.fixture
def fake_ai(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    """Replace the AI layer so no request test ever touches the network.

    Deliberately *not* autouse: ``tests/unit/test_ai.py`` asserts on the real
    ``generate_plan`` / ``revise_plan`` / ``generate_tip`` bodies, and an
    autouse patch here would silently replace the code under test.
    """
    counter = {"n": 0}

    def _next_plan(*_args: object, **_kwargs: object) -> tuple[WorkoutPlan, str]:
        counter["n"] += 1
        return fake_workout_plan(counter["n"]), "fake-model"

    monkeypatch.setattr(plan_service.workout, "generate_plan", _next_plan)
    monkeypatch.setattr(plan_service.workout, "revise_plan", _next_plan)
    monkeypatch.setattr(
        plan_service,
        "generate_tip",
        lambda goal: (f"A focused tip for {goal.value} that is easy to apply today.", False),
    )
    yield
    counter.clear()


@pytest.fixture(autouse=True)
def _fast_hashing() -> Iterator[None]:
    """Argon2 at production cost would make the suite unusably slow."""
    use_fast_hashing()
    yield
    use_fast_hashing()


# --------------------------------------------------------------------------- #
# Database
# --------------------------------------------------------------------------- #
@pytest.fixture
def engine():
    reset_engine()
    engine = get_engine()
    Base.metadata.create_all(engine)
    yield engine
    Base.metadata.drop_all(engine)
    reset_engine()


@pytest.fixture
def db(engine, fake_ai: None) -> Iterator[Session]:
    """A session that is rolled back, so tests never leak rows into each other.

    Depends on ``fake_ai`` so that no service test can reach the real provider.
    """
    session = get_sessionmaker()()
    try:
        yield session
    finally:
        session.rollback()
        session.close()


@pytest.fixture
def make_user(db: Session):
    """Factory for a fully profiled user. ``role`` is a test-only argument.

    Most tests want a user who can already generate a plan, so a complete
    profile is applied by default. Pass ``with_profile=False`` for the
    visitor-on-first-visit case.
    """

    def _make(
        email: str = "asha@example.com",
        password: str = "correct-horse-1",
        display_name: str = "Asha",
        role: Role = Role.USER,
        with_profile: bool = True,
        **profile: object,
    ) -> User:
        user = user_service.register_user(
            db, RegisterInput(display_name=display_name, email=email, password=password)
        )
        if role is not Role.USER:
            user.role = role
        if with_profile:
            user_service.apply_profile(user, _profile_input(display_name, profile), db)
        db.commit()
        return user

    return _make


def _profile_input(display_name: str, profile: dict[str, object]) -> ProfileInput:
    return ProfileInput(
        display_name=profile.pop("display_name", display_name),
        age=profile.pop("age", 28),
        weight_kg=profile.pop("weight_kg", 70.0),
        goal=profile.pop("goal", Goal.MUSCLE_GAIN),
        intensity=profile.pop("intensity", Intensity.MEDIUM),
        notes=profile.pop("notes", "None"),
    )


@pytest.fixture
def make_plan(db: Session, make_user):
    """Factory for saved plans, returning the ORM row."""

    def _make(user: User, version: int = 1) -> Plan:
        if version == 1:
            return plan_service.create_plan(db, user, plan_service.profile_from_user(user))
        parent = plan_service.list_plans_for_user(db, user.id)[-1]
        from app.schemas import FeedbackInput

        return plan_service.create_revision(
            db, user, parent, FeedbackInput(feedback="Please add more conditioning work.")
        )

    return _make


# --------------------------------------------------------------------------- #
# HTTP client
# --------------------------------------------------------------------------- #
@pytest.fixture
def client(engine, fake_ai: None) -> Iterator[TestClient]:
    """Anonymous client, with the AI layer stubbed out."""
    with TestClient(app, raise_server_exceptions=False) as test_client:
        yield test_client


@pytest.fixture
def auth_user(make_user) -> User:
    """The user that ``auth_client`` is signed in as.

    Exposed as its own fixture so a test can create plans *for the signed-in
    user*; a plan belonging to anyone else is correctly a 404.
    """
    return make_user()


@pytest.fixture
def auth_client(client: TestClient, auth_user: User) -> Iterator[TestClient]:
    """Client signed in as a normal user."""
    response = _login(client, auth_user)
    assert response.status_code == 200
    yield client
    client.cookies.clear()


def _login(client: TestClient, user: User, password: str = "correct-horse-1"):
    return client.post(
        "/login",
        data={
            "email": user.email,
            "password": password,
            "csrf_token": csrf_token(client, "/login"),
        },
        follow_redirects=True,
    )


@pytest.fixture
def admin_user(make_user) -> User:
    """An account with the admin role."""
    return make_user(email="admin@example.com", display_name="Root", role=Role.ADMIN)


@pytest.fixture
def admin_client(client: TestClient, admin_user: User) -> Iterator[TestClient]:
    """Client signed in as an admin."""
    response = _login(client, admin_user)
    assert response.status_code == 200
    yield client
    client.cookies.clear()


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def csrf_token(client: TestClient, path: str = "/") -> str:
    """Read the CSRF token out of a rendered form."""
    response = client.get(path)
    match = CSRF_RE.search(response.text)
    assert match, f"no csrf_token form field in {path} (status {response.status_code})"
    return match.group(1)


def post_form(client: TestClient, path: str, path_for_token: str = "/", **data: object):
    """POST a form with a valid CSRF token, following the redirect like a browser."""
    payload = {"csrf_token": csrf_token(client, path_for_token), **data}
    return client.post(path, data=payload, follow_redirects=True)


def post_form_no_redirect(client: TestClient, path: str, path_for_token: str = "/", **data: object):
    payload = {"csrf_token": csrf_token(client, path_for_token), **data}
    return client.post(path, data=payload, follow_redirects=False)


def current_user_id(client: TestClient) -> int | None:
    response = client.get("/")
    match = SESSION_USER_RE.search(response.text)
    return int(match.group(1)) if match else None
