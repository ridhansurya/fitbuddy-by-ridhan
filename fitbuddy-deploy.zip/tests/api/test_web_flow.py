"""End-to-end browser-style tests of the web UI.

The path a real user takes is asserted here: sign up, fill the profile form,
generate a plan, request a revision, and check that the original is still there.
"""

from __future__ import annotations

import re

import pytest
from fastapi.testclient import TestClient

from tests.conftest import csrf_token, post_form, post_form_no_redirect

DAY_CARD_RE = re.compile(r'class="day-card')


class TestHomePage:
    def test_visitor_sees_the_profile_form(self, client: TestClient) -> None:
        response = client.get("/")
        assert response.status_code == 200
        assert 'name="goal"' in response.text
        assert 'name="csrf_token"' in response.text

    def test_medical_disclaimer_is_visible(self, client: TestClient) -> None:
        # Required on every page that shows a plan, including the form.
        assert "not medical advice" in client.get("/").text.lower()

    def test_no_plan_data_leaks_to_a_visitor(self, client: TestClient) -> None:
        assert "Day 1" not in client.get("/").text


class TestRegistration:
    def test_sign_up_then_signed_in(self, client: TestClient) -> None:
        response = post_form(
            client,
            "/register",
            "/register",
            display_name="Asha Rao",
            email="asha@example.com",
            password="Tr0ub4dor-horse",
        )
        assert response.status_code == 200
        assert "Signed in as" in response.text or "logout" in response.text.lower()

    def test_weak_password_shows_a_field_error(self, client: TestClient) -> None:
        response = post_form(
            client,
            "/register",
            "/register",
            display_name="Asha",
            email="asha@example.com",
            password="weak",
        )
        assert response.status_code == 422
        assert "field-error" in response.text

    def test_duplicate_email_is_reported(self, client: TestClient, make_user) -> None:
        make_user(email="taken@example.com")
        response = post_form(
            client,
            "/register",
            "/register",
            display_name="Other",
            email="taken@example.com",
            password="Tr0ub4dor-horse",
        )
        assert response.status_code in (409, 422)
        assert "already exists" in response.text.lower()

    def test_csrf_is_required(self, client: TestClient) -> None:
        response = client.post(
            "/register",
            data={
                "display_name": "Asha",
                "email": "asha@example.com",
                "password": "Tr0ub4dor-horse",
                "csrf_token": "forged",
            },
        )
        assert response.status_code == 403

    def test_missing_csrf_field_is_rejected(self, client: TestClient) -> None:
        response = client.post(
            "/register",
            data={"display_name": "Asha", "email": "a@b.com", "password": "Tr0ub4dor-horse"},
        )
        assert response.status_code == 403


class TestLogin:
    def test_correct_password_signs_in(self, client: TestClient, make_user) -> None:
        user = make_user(email="login@example.com", password="Tr0ub4dor-horse")
        response = post_form(
            client,
            "/login",
            "/login",
            email=user.email,
            password="Tr0ub4dor-horse",
        )
        assert response.status_code == 200

    def test_wrong_password_shows_an_inline_error(self, client: TestClient, make_user) -> None:
        make_user(email="login@example.com", password="Tr0ub4dor-horse")
        response = post_form(
            client, "/login", "/login", email="login@example.com", password="wrong-one-9"
        )
        assert response.status_code == 401
        assert "incorrect" in response.text.lower()

    def test_offsite_next_is_not_followed(self, client: TestClient, make_user) -> None:
        user = make_user(email="login@example.com", password="Tr0ub4dor-horse")
        token = csrf_token(client, "/login?next=https://evil.example.com")
        response = client.post(
            "/login",
            data={"email": user.email, "password": "Tr0ub4dor-horse", "csrf_token": token},
            follow_redirects=True,
        )
        assert "evil.example.com" not in response.text
        assert response.url.path == "/"

    def test_logout_ends_the_session(self, auth_client: TestClient) -> None:
        response = post_form_no_redirect(auth_client, "/logout", "/")
        assert response.status_code == 303
        assert "login" in auth_client.get("/").text.lower()


class TestPlanGeneration:
    def test_generating_a_plan_redirects_to_it(self, client: TestClient, make_user) -> None:
        make_user()
        client.post(
            "/login",
            data={
                "email": "asha@example.com",
                "password": "correct-horse-1",
                "csrf_token": csrf_token(client, "/login"),
            },
        )
        response = post_form_no_redirect(
            client,
            "/plans",
            "/",
            display_name="Asha",
            age="28",
            weight_kg="70",
            goal="muscle_gain",
            intensity="medium",
            notes="No injuries",
        )
        assert response.status_code == 303
        assert response.headers["location"].startswith("/plans/")

    def test_plan_page_shows_seven_days(
        self, auth_client: TestClient, auth_user, make_plan
    ) -> None:
        plan = make_plan(auth_user)
        response = auth_client.get(f"/plans/{plan.id}")
        assert response.status_code == 200
        assert len(DAY_CARD_RE.findall(response.text)) == 7

    def test_plan_page_shows_its_tip(self, auth_client: TestClient, auth_user, make_plan) -> None:
        plan = make_plan(auth_user)
        assert plan.tip in auth_client.get(f"/plans/{plan.id}").text

    def test_model_output_is_html_escaped(
        self, auth_client: TestClient, auth_user, db, make_plan
    ) -> None:
        # Plan text originates from a language model, so it is untrusted input.
        from app.models import Plan

        plan = make_plan(auth_user)
        plan.content = {
            **plan.content,
            "summary": "<script>alert('xss')</script>",
            "days": [
                {**day, "focus": "<img src=x onerror=alert(1)>"} for day in plan.content["days"]
            ],
        }
        db.commit()

        response = auth_client.get(f"/plans/{plan.id}")
        assert response.status_code == 200
        # A raw opening tag would mean the payload can execute. The content is
        # HTML-escaped, so neither literal tag may appear verbatim.
        assert "<script>" not in response.text
        assert "<img" not in response.text
        assert "&lt;script&gt;" in response.text
        assert "&lt;img" in response.text
        assert db.get(Plan, plan.id) is not None

    def test_cannot_view_another_users_plan(
        self, auth_client: TestClient, make_user, make_plan
    ) -> None:
        their_plan = make_plan(make_user(email="other@example.com", display_name="Other"))
        response = auth_client.get(f"/plans/{their_plan.id}")
        assert response.status_code in (403, 404)

    def test_missing_plan_is_a_404(self, auth_client: TestClient) -> None:
        assert auth_client.get("/plans/999999").status_code == 404

    def test_profile_is_optional_on_the_form(self, client: TestClient, make_user) -> None:
        # A visitor who has never filled in a profile is prompted, not crashed.
        user = make_user(with_profile=False)
        client.post(
            "/login",
            data={
                "email": user.email,
                "password": "correct-horse-1",
                "csrf_token": csrf_token(client, "/login"),
            },
        )
        response = post_form(
            client,
            "/plans",
            "/",
            display_name=user.display_name,
            age="28",
            weight_kg="70",
            goal="muscle_gain",
            intensity="medium",
        )
        # A valid profile always wins; the point is that a blank one is handled
        # gracefully rather than surfacing a 500.
        assert response.status_code in (200, 303, 422)


class TestFormValidation:
    @pytest.mark.parametrize(
        ("field", "value"),
        [("age", "5"), ("age", "0"), ("weight_kg", "999"), ("goal", "BECOME_A_HERO")],
    )
    def test_invalid_input_returns_422_with_a_field_error(
        self, auth_client: TestClient, field: str, value: str
    ) -> None:
        data = {
            "display_name": "Asha",
            "age": "28",
            "weight_kg": "70",
            "goal": "muscle_gain",
            "intensity": "medium",
        }
        data[field] = value
        response = post_form(auth_client, "/plans", "/", **data)
        assert response.status_code == 422
        assert "field-error" in response.text

    def test_error_page_never_shows_a_traceback(self, auth_client: TestClient) -> None:
        response = auth_client.get("/plans/not-a-number")
        assert response.status_code in (404, 422)
        assert "Traceback" not in response.text
        assert "app/" not in response.text


class TestRevisions:
    def test_feedback_creates_a_new_version(
        self, auth_client: TestClient, auth_user, make_plan
    ) -> None:
        original = make_plan(auth_user)
        response = post_form_no_redirect(
            auth_client,
            f"/plans/{original.id}/feedback",
            f"/plans/{original.id}",
            feedback="Please add more cardio and one rest day.",
        )
        assert response.status_code == 303
        new_id = int(response.headers["location"].rsplit("/", 1)[-1])
        assert new_id != original.id

    def test_original_plan_is_untouched(
        self, auth_client: TestClient, auth_user, make_plan
    ) -> None:
        original = make_plan(auth_user)
        before = auth_client.get(f"/plans/{original.id}").text
        post_form_no_redirect(
            auth_client,
            f"/plans/{original.id}/feedback",
            f"/plans/{original.id}",
            feedback="Something completely different please.",
        )
        after = auth_client.get(f"/plans/{original.id}").text
        assert "version 1" in before.lower()
        assert "version 1" in after.lower()

    def test_revision_is_labelled_as_version_two(
        self, auth_client: TestClient, auth_user, make_plan
    ) -> None:
        original = make_plan(auth_user)
        response = post_form_no_redirect(
            auth_client,
            f"/plans/{original.id}/feedback",
            f"/plans/{original.id}",
            feedback="Add a second round of sets.",
        )
        revision = response.headers["location"].rsplit("/", 1)[-1]
        assert "version 2" in auth_client.get(f"/plans/{revision}").text.lower()

    def test_feedback_is_required(self, auth_client: TestClient, auth_user, make_plan) -> None:
        original = make_plan(auth_user)
        response = post_form(
            auth_client,
            f"/plans/{original.id}/feedback",
            f"/plans/{original.id}",
            feedback="",
        )
        assert response.status_code == 422

    def test_cannot_revise_another_users_plan(
        self, auth_client: TestClient, make_user, make_plan
    ) -> None:
        other = make_user(email="stranger@example.com", display_name="Stranger")
        their_plan = make_plan(other)
        # CSRF is session-bound, so a token minted for the home page is valid;
        # the ownership check is what must reject this, not the CSRF layer.
        response = post_form_no_redirect(
            auth_client,
            f"/plans/{their_plan.id}/feedback",
            "/",
            feedback="Let me take this over.",
        )
        assert response.status_code in (403, 404)
        assert "/plans/" not in response.headers.get("location", "")

    def test_history_lists_only_my_plans(
        self, auth_client: TestClient, make_user, make_plan
    ) -> None:
        other = make_user(email="hist@example.com", display_name="Hist")
        their_plan = make_plan(other)
        response = auth_client.get("/my-plans")
        assert response.status_code == 200
        assert f"/plans/{their_plan.id}" not in response.text


class TestSecurityHeaders:
    def test_headers_are_present(self, client: TestClient) -> None:
        headers = client.get("/").headers
        assert headers["X-Content-Type-Options"] == "nosniff"
        assert headers["X-Frame-Options"] == "DENY"
        assert "Content-Security-Policy" in headers
        assert "X-Request-ID" in headers

    def test_request_id_is_echoed(self, client: TestClient) -> None:
        response = client.get("/", headers={"X-Request-ID": "abc123def456"})
        assert response.headers["X-Request-ID"] == "abc123def456"

    def test_cookie_has_hardening_attributes(self, client: TestClient) -> None:
        response = client.get("/")
        set_cookie = response.headers.get("set-cookie", "")
        assert "fitbuddy_session=" in set_cookie
        assert "httponly" in set_cookie.lower()
        assert "samesite=lax" in set_cookie.lower()


class TestHealth:
    def test_healthz_reports_ok(self, client: TestClient) -> None:
        body = client.get("/healthz").json()
        assert body["status"] == "ok"
        assert body["database"] == "ok"
        assert "ai_configured" in body
