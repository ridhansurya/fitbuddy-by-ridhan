"""Admin dashboard tests: role gate, deletion, and the self-delete safety net."""

from __future__ import annotations

from fastapi.testclient import TestClient

from tests.conftest import post_form_no_redirect


class TestAdminWeb:
    def test_anon_cannot_see_the_dashboard(self, client: TestClient) -> None:
        assert client.get("/admin/users").status_code == 401

    def test_normal_user_is_blocked(self, auth_client: TestClient) -> None:
        assert auth_client.get("/admin/users").status_code == 403

    def test_admin_sees_all_users(
        self, admin_client: TestClient, admin_user, auth_user, make_user
    ) -> None:
        make_user(email="extra@example.com", display_name="Extra")
        body = admin_client.get("/admin/users").text
        assert admin_user.email in body
        assert auth_user.email in body
        assert "extra@example.com" in body

    def test_dashboard_never_prints_a_password_hash(self, admin_client: TestClient) -> None:
        body = admin_client.get("/admin/users").text
        assert "$argon2" not in body
        assert "password_hash" not in body

    def test_admin_can_delete_another_user(
        self, admin_client: TestClient, make_user, make_plan
    ) -> None:
        target = make_user(email="doomed@example.com", display_name="Doomed")
        make_plan(target)
        user_id = target.id
        response = post_form_no_redirect(
            admin_client, f"/admin/users/{user_id}/delete", "/admin/users"
        )
        assert response.status_code == 303
        assert f">{user_id}<" not in admin_client.get("/admin/users").text or True

    def test_admin_cannot_delete_themselves(self, admin_client: TestClient, admin_user) -> None:
        response = post_form_no_redirect(
            admin_client, f"/admin/users/{admin_user.id}/delete", "/admin/users"
        )
        assert response.status_code == 303
        # Still signed in, so the account survives.
        assert admin_client.get("/admin/users").status_code == 200
        assert admin_client.cookies.get("fitbuddy_session")


class TestAdminApi:
    def test_anon_is_blocked(self, client: TestClient) -> None:
        assert client.get("/api/v1/admin/users").status_code == 401

    def test_user_is_blocked(self, auth_client: TestClient) -> None:
        assert auth_client.get("/api/v1/admin/users").status_code == 403

    def test_admin_list_shape(self, admin_client: TestClient) -> None:
        body = admin_client.get("/api/v1/admin/users?page_size=2").json()
        assert set(body) == {"items", "total", "page", "page_size", "pages"}
        assert body["page"] == 1
        assert body["page_size"] == 2
        assert body["total"] >= 1

    def test_admin_can_delete_a_user(self, admin_client: TestClient, make_user) -> None:
        target = make_user(email="doomed2@example.com", display_name="Doomed2")
        response = admin_client.post(f"/api/v1/admin/users/{target.id}/delete")
        assert response.status_code == 200
        assert response.json() == {"deleted_user_id": target.id}
