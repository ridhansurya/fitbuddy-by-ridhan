"""API contract tests.

The API mirrors the web app (same session cookie, same CSRF-free /api/v1
namespace). These assert the JSON shape that the front-end would rely on, plus
the two cross-checks that matter most: plans the user did not create are
invisible, and posted privilege fields are ignored.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

CREATE_BODY = {
    "display_name": "Asha",
    "age": 28,
    "weight_kg": 70.0,
    "goal": "muscle_gain",
    "intensity": "medium",
    "notes": "No injuries",
}


class TestAuthentication:
    def test_anonymous_api_requests_are_401(self, client: TestClient) -> None:
        assert client.get("/api/v1/plans").status_code == 401
        assert client.post("/api/v1/plans", json=CREATE_BODY).status_code == 401
        assert client.get("/api/v1/tips?goal=muscle_gain").status_code == 401
        assert client.get("/api/v1/quota").status_code == 401
        assert client.get("/api/v1/me").status_code == 401

    def test_bad_credentials_reject_with_a_clear_message(
        self, client: TestClient, make_user
    ) -> None:
        make_user(email="api@example.com", password="Tr0ub4dor-horse")
        response = client.post("/api/v1/plans", json=CREATE_BODY)
        assert response.status_code == 401  # not signed in yet
        body = response.json()["error"]
        assert body["code"] == "UNAUTHENTICATED"
        assert body["message"]
        assert "request_id" in body


class TestMe:
    def test_me_reports_only_my_profile(self, auth_client: TestClient, auth_user) -> None:
        body = auth_client.get("/api/v1/me").json()
        assert body["email"] == auth_user.email
        assert body["role"] == "user"
        assert "password_hash" not in body

    def test_me_does_not_leak_other_fields(self, auth_client: TestClient) -> None:
        body = auth_client.get("/api/v1/me").json()
        assert set(body) == {
            "id",
            "email",
            "display_name",
            "role",
            "age",
            "weight_kg",
            "goal",
            "intensity",
            "created_at",
        }


class TestPlanApi:
    def test_creating_a_plan_returns_the_plan(self, auth_client: TestClient) -> None:
        response = auth_client.post("/api/v1/plans", json=CREATE_BODY)
        assert response.status_code == 200
        body = response.json()
        assert body["version"] == 1
        assert body["kind"] == "original"
        assert body["parent_plan_id"] is None
        assert body["owner_display_name"]
        assert len(body["content"]["days"]) == 7

    def test_creating_a_plan_consumes_quota(self, auth_client: TestClient) -> None:
        assert auth_client.post("/api/v1/plans", json=CREATE_BODY).json()["version"] == 1
        assert auth_client.get("/api/v1/quota").json()["remaining_today"] <= 9

    def test_create_ignores_a_posted_user_id(self, auth_client: TestClient, auth_user) -> None:
        # Privilege escalation attempt: the plan must stay owned by the caller.
        body = {**CREATE_BODY, "user_id": 999_999}
        response = auth_client.post("/api/v1/plans", json=body)
        assert response.status_code == 422
        assert "extra" in response.json()["error"]["message"].lower()

    def test_create_ignores_a_posted_role(self, auth_client: TestClient) -> None:
        body = {**CREATE_BODY, "role": "admin"}
        assert auth_client.post("/api/v1/plans", json=body).status_code == 422

    def test_list_returns_only_my_plans(
        self, auth_client: TestClient, auth_user, make_user, make_plan
    ) -> None:
        make_plan(auth_user)
        other = make_user(email="other@example.com", display_name="Other")
        make_plan(other)
        body = auth_client.get("/api/v1/plans").json()
        assert isinstance(body, list)
        assert all(item["user_id"] == auth_user.id for item in body)
        assert len(body) == 1

    def test_revision_returns_the_new_version(
        self, auth_client: TestClient, auth_user, make_plan
    ) -> None:
        original = make_plan(auth_user)
        response = auth_client.post(
            f"/api/v1/plans/{original.id}/revisions",
            json={"feedback": "Add more cardio"},
        )
        assert response.status_code == 200
        revision = response.json()
        assert revision["version"] == 2
        assert revision["kind"] == "revision"
        assert revision["parent_plan_id"] == original.id
        assert revision["feedback_text"] == "Add more cardio"

    def test_revision_is_immutable(self, auth_client: TestClient, auth_user, make_plan) -> None:
        original = make_plan(auth_user)
        before = auth_client.get(f"/api/v1/plans/{original.id}").json()
        auth_client.post(f"/api/v1/plans/{original.id}/revisions", json={"feedback": "Faster now"})
        after = auth_client.get(f"/api/v1/plans/{original.id}").json()
        assert before["version"] == after["version"] == 1
        assert before["content"] == after["content"]

    def test_listing_revisions_walks_the_chain(
        self, auth_client: TestClient, auth_user, make_plan
    ) -> None:
        original = make_plan(auth_user)
        second = auth_client.post(
            f"/api/v1/plans/{original.id}/revisions", json={"feedback": "One"}
        ).json()
        third = auth_client.post(
            f"/api/v1/plans/{second['id']}/revisions", json={"feedback": "Two"}
        ).json()
        chain = auth_client.get(f"/api/v1/plans/{third['id']}/revisions").json()
        assert [p["version"] for p in chain] == [1, 2, 3]

    def test_someone_elses_plan_is_hidden(
        self, auth_client: TestClient, make_user, make_plan
    ) -> None:
        their_plan = make_plan(make_user(email="hidden@example.com", display_name="Hidden"))
        assert auth_client.get(f"/api/v1/plans/{their_plan.id}").status_code == 404


class TestTipApi:
    def test_tip_endpoint_enforces_the_word_limit(self, auth_client: TestClient) -> None:
        for goal in ("weight_loss", "muscle_gain", "endurance", "general_fitness", "flexibility"):
            body = auth_client.get(f"/api/v1/tips?goal={goal}").json()
            assert body["goal"] == goal
            assert body["word_count"] == len(body["tip"].split())
            assert body["word_count"] <= 60

    def test_tip_requires_a_valid_goal(self, auth_client: TestClient) -> None:
        assert auth_client.get("/api/v1/tips?goal=become_a_hero").status_code == 422


class TestInputValidation:
    @pytest.mark.parametrize(
        ("mutations", "want"),
        [
            ({"age": 5}, 422),
            ({"weight_kg": 999}, 422),
            ({"goal": "hero_mode"}, 422),
            ({"notes": "x" * 2000}, 422),
            ({"age": 28, "weight_kg": "not-a-number"}, 422),
        ],
    )
    def test_invalid_bodies_are_422(
        self, auth_client: TestClient, mutations: dict, want: int
    ) -> None:
        response = auth_client.post("/api/v1/plans", json={**CREATE_BODY, **mutations})
        assert response.status_code == want

    def test_errors_never_leak_internals(self, auth_client: TestClient) -> None:
        response = auth_client.post("/api/v1/plans", json={**CREATE_BODY, "age": 5})
        body = response.json()["error"]
        assert "Traceback" not in body["message"]
        assert "app/" not in str(body)
        assert "exception" not in body["message"].lower()


class TestQuotaAndRateLimit:
    def test_quota_reports_remaining_today(self, auth_client: TestClient) -> None:
        body = auth_client.get("/api/v1/quota").json()
        assert set(body) == {"remaining_today"}
        assert body["remaining_today"] >= 0


class TestAdminApi:
    def test_admin_can_list_users(self, admin_client: TestClient, admin_user, auth_user) -> None:
        body = admin_client.get("/api/v1/admin/users").json()
        emails = [row["user"]["email"] for row in body["items"]]
        assert admin_user.email in emails
        assert "password_hash" not in str(body)

    def test_non_admin_cannot_list_users(self, auth_client: TestClient) -> None:
        assert auth_client.get("/api/v1/admin/users").status_code == 403

    def test_admin_can_delete_a_user(self, admin_client: TestClient, make_user) -> None:
        target = make_user(email="doomed@example.com", display_name="Doomed")
        response = admin_client.post(f"/api/v1/admin/users/{target.id}/delete")
        assert response.status_code == 200

    def test_admin_cannot_delete_themselves(self, admin_client: TestClient, admin_user) -> None:
        # Removing your own account silently would be a data-loss incident, so
        # the API mirrors the web form's refusal.
        response = admin_client.post(f"/api/v1/admin/users/{admin_user.id}/delete")
        assert response.status_code == 403
        assert admin_client.get("/api/v1/me").status_code == 200
