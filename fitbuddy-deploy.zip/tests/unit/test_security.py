"""Unit tests for password hashing, open-redirect protection and settings."""

from __future__ import annotations

import pytest

from app.config import get_settings
from app.errors import AppError, AuthenticationError, ValidationError
from app.routes.auth import _safe_next
from app.security import hash_password, verify_password


def _request_with_next(target: str) -> object:
    """Build a minimal request-like object exposing the query string."""
    scope = {
        "type": "http",
        "method": "GET",
        "path": "/login",
        "query_string": f"next={target}".encode(),
        "headers": [],
        "app": None,
    }
    from starlette.requests import Request

    return Request(scope)


class TestPasswordHashing:
    def test_hash_is_argon2_and_verifies(self) -> None:
        digest = hash_password("correct-horse-1")
        assert digest.startswith("$argon2")
        assert verify_password("correct-horse-1", digest) is True

    def test_wrong_password_is_rejected(self) -> None:
        digest = hash_password("correct-horse-1")
        assert verify_password("wrong-horse-1", digest) is False

    def test_same_password_hashes_differently(self) -> None:
        assert hash_password("same-password") != hash_password("same-password")

    def test_malformed_hash_returns_false_instead_of_raising(self) -> None:
        # A corrupt stored hash must not become a 500 on the login page.
        assert verify_password("anything", "not-a-real-hash") is False
        assert verify_password("anything", "") is False


class TestSafeNext:
    @pytest.mark.parametrize("target", ["/plans/1", "/my-plans", "/?x=1", "/admin/users"])
    def test_local_paths_are_kept(self, target: str) -> None:
        assert _safe_next(_request_with_next(target)) == target

    def test_empty_next_defaults_to_home(self) -> None:
        assert _safe_next(_request_with_next("")) == "/"

    @pytest.mark.parametrize(
        "target",
        [
            "https%3A%2F%2Fevil.example.com%2Fsteal",
            "%2F%2Fevil.example.com%2Fsteal",
            "javascript%3Aalert(1)",
            "%2F%5C%5Cevil.example.com",
        ],
    )
    def test_offsite_targets_fall_back_to_home(self, target: str) -> None:
        # Open redirect guard: a forged ?next= must never bounce a just
        # authenticated user to another origin.
        assert _safe_next(_request_with_next(target)) == "/"


class TestSettings:
    def test_sqlalchemy_url_is_normalised(self) -> None:
        assert get_settings().sqlalchemy_url.startswith("sqlite:///")

    def test_test_environment_is_active(self) -> None:
        assert get_settings().app_env == "test"

    def test_insecure_secret_is_rejected_outside_local(self) -> None:
        from pydantic import ValidationError as PydanticValidationError

        from app.config import Settings

        with pytest.raises(PydanticValidationError):
            Settings(app_env="production", secret_key="change-me-to-a-long-random-string")

    def test_every_error_is_an_app_error_with_a_code(self) -> None:
        # One base class means one error envelope for all failures.
        assert issubclass(AuthenticationError, AppError)
        assert issubclass(ValidationError, AppError)
        assert AuthenticationError("no").code == "UNAUTHENTICATED"
        assert ValidationError("bad", field="email").field == "email"
