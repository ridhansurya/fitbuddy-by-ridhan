"""CLI tests: the operations an operator actually runs."""

from __future__ import annotations

from types import SimpleNamespace

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.cli import cmd_create_admin, cmd_list_users, cmd_reset_db, cmd_seed_demo
from app.enums import PlanKind, Role
from app.models import Plan, User


def test_create_admin_creates_an_admin(capsys, db: Session) -> None:
    args = SimpleNamespace(email="admin@example.com", password="Tr0ub4dor-horse", name="Root")
    assert cmd_create_admin(args) == 0
    admin = db.scalar(select(User).where(User.email == "admin@example.com"))
    assert admin is not None
    assert admin.role is Role.ADMIN
    assert "created admin" in capsys.readouterr().out.lower()


def test_create_admin_refuses_a_duplicate(capsys, db: Session) -> None:
    cmd_create_admin(SimpleNamespace(email="dup@example.com", password="Tr0ub4dor-horse", name="A"))
    from app.cli import main

    # main() maps ConflictError to exit code 1 with a message on stderr.
    assert (
        main(["create-admin", "--email", "dup@example.com", "--password", "X-1", "--name", "A"])
        == 1
    )


def test_seed_demo_creates_coach_and_members(capsys, db: Session) -> None:
    args = SimpleNamespace(admin_email="coach@demo.dev")
    assert cmd_seed_demo(args) == 0
    coach = db.scalar(select(User).where(User.email == "coach@demo.dev"))
    assert coach is not None and coach.role is Role.ADMIN
    emails = {u.email for u in db.scalars(select(User)).all()}
    assert {"asha@demo.dev", "karthik@demo.dev"} <= emails
    plans = db.scalars(select(Plan).where(Plan.user_id != coach.id)).all()
    assert len(plans) >= 4  # two users, two+ revisions


def test_seed_demo_versions_follow_the_chain_rules(db: Session) -> None:
    cmd_seed_demo(SimpleNamespace(admin_email="coach@demo.dev"))
    users = db.scalars(select(User)).all()
    assert any(u.email == "coach@demo.dev" for u in users)
    for user in users:
        plans = sorted(user.plans, key=lambda p: p.version)
        if not plans:
            continue  # the admin account has no plans of its own
        assert [p.version for p in plans] == list(range(1, len(plans) + 1))
        original = plans[0]
        assert original.kind is PlanKind.ORIGINAL
        assert original.parent_plan_id is None
        for later in plans[1:]:
            assert later.kind is PlanKind.REVISION
        # Original is never rewritten: still version 1 after the family exists.
        assert original.version == 1


def test_seed_demo_survives_repeat_runs(capsys, db: Session) -> None:
    cmd_seed_demo(SimpleNamespace(admin_email="coach@demo.dev"))
    before = db.scalar(select(func.count()).select_from(User))
    # A second run must not duplicate accounts: ConflictError -> exit code 1.
    from app.cli import main

    assert main(["seed-demo", "--admin-email", "coach@demo.dev"]) == 1
    assert db.scalar(select(func.count()).select_from(User)) == before


def test_reset_db_clears_everything(db: Session, make_user) -> None:
    make_user()
    assert db.scalar(select(func.count()).select_from(User)) >= 1
    assert cmd_reset_db(SimpleNamespace()) == 0
    db.expire_all()
    assert db.scalar(select(func.count()).select_from(User)) == 0
    assert db.scalar(select(func.count()).select_from(Plan)) == 0


def test_list_users_prints_rows(capsys, db: Session, make_user) -> None:
    make_user(email="listed@example.com", display_name="Listed")
    assert cmd_list_users(SimpleNamespace()) == 0
    out = capsys.readouterr().out
    assert "listed@example.com" in out
    assert "user" in out
    # Never print material that could help an attacker.
    assert "argon2" not in out and "password_hash" not in out
