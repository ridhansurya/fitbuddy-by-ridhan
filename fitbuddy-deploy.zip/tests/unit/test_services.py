"""Service-layer tests: accounts, plans, versioning and quotas.

These exercise the rules that the HTTP layer relies on, without going through
HTTP: plan immutability, per-user version numbering, and the isolation between
users.
"""

from __future__ import annotations

import pytest
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.enums import Goal, Intensity, Role
from app.errors import (
    AuthenticationError,
    ConflictError,
    NotFoundError,
    PermissionDeniedError,
    ValidationError,
)
from app.models import Plan, PlanKind, User
from app.schemas import FeedbackInput, ProfileInput, RegisterInput
from app.services import plan_service, user_service


class TestRegistration:
    def test_new_user_has_no_profile_yet(self, db: Session, make_user) -> None:
        user = make_user(with_profile=False)
        assert user.age is None
        assert user.goal is None
        assert user.role is Role.USER

    def test_password_is_never_stored_in_the_clear(self, db: Session, make_user) -> None:
        user = make_user(password="Tr0ub4dor-unique-secret")
        assert "Tr0ub4dor" not in (user.password_hash or "")
        assert user.password_hash.startswith("$argon2")

    def test_duplicate_email_is_a_conflict(self, db: Session, make_user) -> None:
        make_user(email="dupe@example.com")
        with pytest.raises(ConflictError):
            user_service.register_user(
                db,
                RegisterInput(
                    display_name="Other", email="dupe@example.com", password="another-one-1"
                ),
            )

    def test_email_is_normalised(self, db: Session, make_user) -> None:
        user = make_user(email="  MiXeD@Example.COM  ")
        assert user.email == "mixed@example.com"


class TestAuthentication:
    def test_correct_password_authenticates(self, db: Session, make_user) -> None:
        user = make_user(email="auth@example.com", password="good-password-1")
        assert user_service.authenticate(db, "auth@example.com", "good-password-1").id == user.id

    def test_wrong_password_is_rejected(self, db: Session, make_user) -> None:
        make_user(email="auth@example.com", password="good-password-1")
        with pytest.raises(AuthenticationError):
            user_service.authenticate(db, "auth@example.com", "wrong-password-1")

    def test_unknown_email_gives_the_same_error(self, db: Session, make_user) -> None:
        # Identical message for unknown account and wrong password, so the
        # login form cannot be used to enumerate accounts.
        make_user(email="real@example.com", password="good-password-1")
        with pytest.raises(AuthenticationError) as unknown:
            user_service.authenticate(db, "ghost@example.com", "good-password-1")
        with pytest.raises(AuthenticationError) as wrong:
            user_service.authenticate(db, "real@example.com", "nope-not-it-1")
        assert unknown.value.message == wrong.value.message


class TestProfiles:
    def test_profile_is_persisted(self, db: Session, make_user) -> None:
        user = make_user()
        user_service.apply_profile(
            user,
            ProfileInput(
                display_name="Asha R",
                age=28,
                weight_kg=70.0,
                goal=Goal.MUSCLE_GAIN,
                intensity=Intensity.MEDIUM,
                notes="Knee feels fine",
            ),
            db,
        )
        assert user.age == 28
        assert user.goal is Goal.MUSCLE_GAIN

    def test_plan_generation_refuses_an_incomplete_profile(self, db: Session, make_user) -> None:
        # A visitor who skipped the profile must be sent back to the form with
        # a named field, not shown a server error.
        user = make_user(with_profile=False)
        with pytest.raises(ValidationError) as excinfo:
            plan_service.create_plan(db, user, plan_service.profile_from_user(user))
        assert excinfo.value.field == "age"


class TestPlanVersioning:
    def test_first_plan_is_version_one_with_no_parent(self, db: Session, make_user) -> None:
        user = make_user()
        plan = plan_service.create_plan(db, user, plan_service.profile_from_user(user))
        assert plan.version == 1
        assert plan.parent_plan_id is None
        assert plan.kind is PlanKind.ORIGINAL

    def test_revision_increments_and_links_to_parent(self, db: Session, make_user) -> None:
        user = make_user()
        first = plan_service.create_plan(db, user, plan_service.profile_from_user(user))
        second = plan_service.create_revision(
            db, user, first, FeedbackInput(feedback="Add more cardio")
        )
        assert second.version == 2
        assert second.parent_plan_id == first.id
        assert second.kind is PlanKind.REVISION

    def test_original_is_never_mutated(self, db: Session, make_user) -> None:
        # The whole point of immutable versioning.
        user = make_user()
        first = plan_service.create_plan(db, user, plan_service.profile_from_user(user))
        before = first.content
        plan_service.create_revision(
            db, user, first, FeedbackInput(feedback="Completely different week")
        )
        db.refresh(first)
        assert first.content == before
        assert first.version == 1

    def test_versioning_is_per_user(self, db: Session, make_user) -> None:
        one = make_user(email="one@example.com")
        two = make_user(email="two@example.com", display_name="Two")
        a = plan_service.create_plan(db, one, plan_service.profile_from_user(one))
        b = plan_service.create_plan(db, two, plan_service.profile_from_user(two))
        assert a.version == 1
        assert b.version == 1, "a second user must not inherit a version counter"

    def test_third_revision_continues_the_chain(self, db: Session, make_user) -> None:
        user = make_user()
        first = plan_service.create_plan(db, user, plan_service.profile_from_user(user))
        second = plan_service.create_revision(db, user, first, FeedbackInput(feedback="One"))
        third = plan_service.create_revision(db, user, second, FeedbackInput(feedback="Two"))
        assert third.version == 3
        assert third.parent_plan_id == second.id
        chain = plan_service.plan_chain(db, third)
        assert [p.version for p in chain] == [1, 2, 3]

    def test_chain_root_of_a_revision_is_the_original(self, db: Session, make_user) -> None:
        user = make_user()
        first = plan_service.create_plan(db, user, plan_service.profile_from_user(user))
        second = plan_service.create_revision(db, user, first, FeedbackInput(feedback="One"))
        assert plan_service.chain_root(db, second).id == first.id

    def test_duplicate_version_is_blocked_by_the_database(self, db: Session, make_user) -> None:
        # A race between two tabs must fail loudly, not silently overwrite.
        user = make_user()
        plan = plan_service.create_plan(db, user, plan_service.profile_from_user(user))
        clone = Plan(
            user_id=user.id,
            version=1,
            kind=PlanKind.ORIGINAL,
            content=plan.content,
            tip=plan.tip,
            model_name=plan.model_name,
            prompt_version=plan.prompt_version,
            profile_snapshot=plan.profile_snapshot,
        )
        db.add(clone)
        with pytest.raises(IntegrityError):
            db.flush()
        db.rollback()

    def test_another_users_revision_is_refused(self, db: Session, make_user) -> None:
        victim = make_user(email="victim@example.com", display_name="Victim")
        attacker = make_user(email="attacker@example.com", display_name="Attacker")
        victim_plan = plan_service.create_plan(db, victim, plan_service.profile_from_user(victim))
        with pytest.raises(PermissionDeniedError):
            plan_service.create_revision(
                db, attacker, victim_plan, FeedbackInput(feedback="Mine now")
            )
        # Nothing was written, and the victim's plan is untouched.
        assert plan_service.get_plan(db, victim_plan.id).version == 1
        assert plan_service.list_plans_for_user(db, victim.id) == [victim_plan]

    def test_latest_plan_returns_the_newest_revision(self, db: Session, make_user) -> None:
        user = make_user()
        first = plan_service.create_plan(db, user, plan_service.profile_from_user(user))
        second = plan_service.create_revision(db, user, first, FeedbackInput(feedback="More"))
        assert plan_service.latest_plan(db, user.id).id == second.id

    def test_missing_plan_raises_not_found(self, db: Session) -> None:
        with pytest.raises(NotFoundError):
            plan_service.get_plan(db, 999_999)


class TestPlanIsolation:
    def test_plans_are_listed_only_for_their_owner(self, db: Session, make_user, make_plan) -> None:
        one = make_user(email="one@example.com", display_name="One")
        two = make_user(email="two@example.com", display_name="Two")
        make_plan(one)
        make_plan(two)
        one_ids = {p.id for p in plan_service.list_plans_for_user(db, one.id)}
        two_ids = {p.id for p in plan_service.list_plans_for_user(db, two.id)}
        assert one_ids and two_ids
        assert one_ids.isdisjoint(two_ids)


class TestDeletion:
    def test_deleting_a_user_removes_their_plans(self, db: Session, make_user, make_plan) -> None:
        # Regression: SQLite ignores ON DELETE CASCADE unless foreign keys are
        # enabled per connection, so this used to leave orphaned plans behind.
        user = make_user()
        make_plan(user)
        make_plan(user, version=2)
        user_id = user.id
        user_service.delete_user(db, user_id)
        db.expire_all()
        assert db.get(User, user_id) is None
        assert db.scalar(select(func.count()).select_from(Plan)) == 0
        assert db.scalar(select(func.count()).select_from(Plan).where(Plan.user_id == user_id)) == 0

    def test_deleting_a_plan_removes_its_revisions(self, db: Session, make_user, make_plan) -> None:
        user = make_user()
        first = make_plan(user)
        revision = make_plan(user, version=2)
        db.delete(revision)
        db.commit()
        assert db.get(Plan, first.id) is not None

    def test_deleting_a_missing_user_raises(self, db: Session) -> None:
        with pytest.raises(NotFoundError):
            user_service.delete_user(db, 999_999)


class TestAdminListing:
    def test_pagination_reports_totals(self, db: Session, make_user) -> None:
        for index in range(5):
            make_user(email=f"user{index}@example.com", display_name=f"User {index}")
        rows, total = user_service.list_users_paginated(db, page=1, page_size=2)
        assert total == 5
        assert len(rows) == 2
        last_page, _ = user_service.list_users_paginated(db, page=3, page_size=2)
        assert len(last_page) == 1

    def test_search_filters_by_name_and_email(self, db: Session, make_user) -> None:
        make_user(email="alice@example.com", display_name="Alice Smith")
        make_user(email="bob@example.com", display_name="Bob Jones")
        rows, total = user_service.list_users_paginated(db, query="alice")
        assert total == 1
        assert rows[0][0].email == "alice@example.com"

    def test_rows_carry_plan_count_and_latest_version(
        self, db: Session, make_user, make_plan
    ) -> None:
        user = make_user()
        first = make_plan(user)
        make_plan(user, version=2)
        rows, _ = user_service.list_users_paginated(db, query=user.email)
        _user_row, plan_count, latest = rows[0]
        assert plan_count == 2
        assert latest is not None
        assert latest.version == 2
        assert first.user_id == user.id
