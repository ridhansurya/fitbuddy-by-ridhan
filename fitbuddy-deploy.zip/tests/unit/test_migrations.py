"""Migration integrity tests.

Alembic is the source of truth for the schema. A migration that cannot reverse
cleanly is a deployment hazard, so downgrade→upgrade is exercised here against
a scratch database for every revision prior to the head.
"""

from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]


def _alembic(*args: str, url: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [f"{REPO}/venv/bin/python", "-m", "alembic", *args],
        cwd=REPO,
        env={**__import__("os").environ, "DATABASE_URL": url},
        capture_output=True,
        text=True,
        check=False,
    )


@pytest.fixture()
def scratch_db() -> str:
    """A disposable SQLite file for each run, so no data is touched."""
    with tempfile.TemporaryDirectory() as tmp:
        yield f"sqlite:////{tmp}/migrations.db"


def test_upgrade_to_head_and_downgrade_to_base(scratch_db: str) -> None:
    upgrade = _alembic("upgrade", "head", url=scratch_db)
    assert upgrade.returncode == 0, upgrade.stderr
    # Alembic logs through Python logging, so the progress lines are on stderr.
    assert "Running upgrade" in upgrade.stdout + upgrade.stderr

    downgrade = _alembic("downgrade", "base", url=scratch_db)
    assert downgrade.returncode == 0, downgrade.stderr

    # Re-upgrading after a downgrade must reproduce the exact same schema.
    re_upgrade = _alembic("upgrade", "head", url=scratch_db)
    assert re_upgrade.returncode == 0, re_upgrade.stderr


def test_seeded_data_survives_a_downgrade_upgrade_cycle(scratch_db: str) -> None:
    _alembic("upgrade", "head", url=scratch_db)
    cmd = subprocess.run(
        [
            f"{REPO}/venv/bin/python",
            "-c",
            """
import os, sys
sys.path.insert(0, os.getcwd())
from sqlalchemy import select
from app.database import get_sessionmaker
from app.models import Plan, User
from app.security import use_fast_hashing, hash_password
use_fast_hashing()
db = get_sessionmaker()()
u = User(email="mig@example.com", password_hash=hash_password("Tr0ub4dor-horse"), display_name="Mig")
db.add(u); db.commit(); db.refresh(u)
db.add(Plan(user_id=u.id, version=1, kind="original", content={"summary": "s", "days": [], "notes": []}, tip="t", model_name="m", prompt_version="p", profile_snapshot={}))
db.commit()
print("seeded", u.id)
""",
        ],
        cwd=REPO,
        env={**__import__("os").environ, "DATABASE_URL": scratch_db},
        capture_output=True,
        text=True,
    )
    assert cmd.returncode == 0, cmd.stderr
    assert "seeded" in cmd.stdout

    # Downgrade destroys the data - that is expected and safe - but the schema
    # must still return to head cleanly afterwards.
    assert _alembic("downgrade", "base", url=scratch_db).returncode == 0
    assert _alembic("upgrade", "head", url=scratch_db).returncode == 0


def test_enum_values_are_stable_strings(scratch_db: str) -> None:
    # The migration stores enums as their lowercase values, never Python
    # member names, so renaming a member in code cannot corrupt stored rows.
    from alembic.config import Config
    from alembic.script import ScriptDirectory

    config = Config(str(REPO / "alembic.ini"))
    revisions = list(ScriptDirectory.from_config(config).walk_revisions())
    assert revisions, "at least one migration must exist"
    assert all(script.module.upgrade for script in revisions), "every migration needs upgrade()"
    assert all(script.module.downgrade for script in revisions), "every migration needs downgrade()"
