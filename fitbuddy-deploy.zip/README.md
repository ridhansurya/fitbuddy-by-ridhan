# FitBuddy

A personal AI fitness coach. Fill in a short profile, get a structured 7-day
plan, and revise it as many times as you like — every revision is kept as an
immutable version, so you always have your history and a coach can see what
changed and why.

FitBuddy is a FastAPI app with a server-rendered dark UI, a JSON API under
`/api/v1`, sessions-based authentication, and Google Gemini (or any OpenAI-compatible provider) doing the
generation.

## Features

- **Structured plans, not walls of text.** The plan is validated against a JSON
  Schema before it is shown or stored. A plan that is not exactly seven days,
  missing a rest day, or listing exercises on a rest day is rejected and
  retried once — never shown to you.
- **Immutable versioning.** The original plan is never edited. Every request
  for a change produces a new version linked to the one before it, so the full
  history is always reconstructable.
- **Signed-in users and roles.** Sessions are signed cookies (Argon2 for
  password hashing, CSRF on every HTML form). Account creation is public;
  admin accounts are created by the operator:
  `python -m app.cli create-admin ...`.
- **A bonus nutrition/recovery tip** per goal, cached in-process with a fallback
  so a tip outage can never take down plan generation.
- **A coach dashboard.** Admins see every user, their plan counts, and the
  latest version, and can delete accounts (never their own).
- **Simplest possible AI usage.** Two bounded, single-shot model calls per
  action. No agent loop, no tool calling.
- **Safety rails by design.** No medical advice, no micro-managed credentials
  or fine details in prompts, no data stored without the user's consent in the
  process, and plan text is untrusted model output (HTML-escaped everywhere).

## Tech stack

- FastAPI + Starlette, SQLAlchemy 2.0, Alembic, Pydantic v2, **SQLite** out of
  the box (PostgreSQL works via `DATABASE_URL`).
- Jinja2 templates, no JavaScript framework.
- `httpx`, `google-genai`, `argon2-cffi`.

## Requirements

- Python 3.11+ (developed against 3.14)
- An AI API key (Gemini or OpenAI-compatible) for live plan generation

## Setup

```bash
cd FitBuddy
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Create a `.env` file from the template and at minimum set a signing key:

```bash
cp .env.example .env
# generate a long random value for SECRET_KEY, e.g.:
#   python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Set `GEMINI_API_KEY=<your key>` in `.env` to enable live generation. Without a
key the app runs fine; plan generation reports a clear "AI not configured"
error, which is also what the `/healthz` endpoint reports.

You can swap the whole provider without code changes by setting `AI_PROVIDER`
and the matching key:

- `AI_PROVIDER=gemini` (default) → `GEMINI_API_KEY` — see `GEMINI_MODEL_*`
- `AI_PROVIDER=openai` → `OPENAI_API_KEY`, `OPENAI_BASE_URL` and
  `OPENAI_MODEL_*`. Any OpenAI-compatible `/chat/completions` endpoint works:
  OpenAI (`https://api.openai.com/v1`), Groq
  (`https://api.groq.com/openai/v1`), OpenRouter
  (`https://openrouter.ai/api/v1`), etc.

Because AI providers throttle models independently (503 high demand, 429
quota), every generation also walks the `*_MODEL_FALLBACKS` list and uses the
first model that responds. The JSON returned is always validated against the
plan schema before it can be stored - poorly-formed model output is retried
once and then fails cleanly, it is never treated as a real plan.

## Run

```bash
uvicorn app.main:app --reload --port 8000
```

Open <http://localhost:8000>, create an account, fill in the profile and
generate your first plan. Interactive API docs at <http://localhost:8000/docs>.

### One-time setup: the database

Migrations are managed with Alembic:

```bash
alembic upgrade head
```

The CLI creates tables automatically if you use it first (convenience for a
fresh checkout), but Alembic remains the source of truth.

### Demo data

```bash
python -m app.cli seed-demo
```

Creates a coach account (`coach@demo.dev`), two members, and a small amount of
revision history so the admin dashboard has an original-vs-revised comparison.
All demo passwords are `demopass123` (development only).

### Admin account

```bash
python -m app.cli create-admin --email you@example.com --password 'a-good-password-1' --name "You"
```

Admin signup through the public form is deliberately impossible.

## CLI

```
python -m app.cli create-admin --email ... --password ... [--name ...]
python -m app.cli seed-demo [--admin-email coach@demo.dev]
python -m app.cli list-users
python -m app.cli reset-db        # local development only
```

## Configuration

All settings live in `app/config.py`, overridable through environment
variables (they map 1:1 to field names) or `.env`. The important ones:

| Variable                        | Default                  | Notes                                   |
| ------------------------------- | ------------------------ | --------------------------------------- |
| `SECRET_KEY`                    | *(insecure)*             | Long random value; **required** outside `local` |
| `APP_ENV`                       | `local`                  | `local`, `test` or `production`; production refuses insecure keys and empty AI keys |
| `DATABASE_URL`                  | `sqlite:///./fitbuddy.db`| Any SQLAlchemy URL (e.g. PostgreSQL)    |
| `AI_PROVIDER`                   | `gemini`                 | `gemini` or `openai` (any OpenAI-compatible endpoint) |
| `GEMINI_API_KEY`                | *(empty)*                | Disables live Gemini calls when empty   |
| `GEMINI_MODEL_PLAN`             | `gemini-3.6-flash` | Model used for plans; schema-incompatible keys are auto-dropped and the client falls back to JSON-only when a model rejects the schema |
| `GEMINI_MODEL_TIP`              | `gemini-3.6-flash` | Model used for tips                     |
| `GEMINI_MODEL_FALLBACKS`        | `gemini-3-flash-preview,gemini-3.5-flash` | Comma-separated models tried after the primary when it is throttled (503/429) |
| `OPENAI_API_KEY`                | *(empty)*                | Disables live OpenAI-compatible calls when empty |
| `OPENAI_BASE_URL`               | `https://api.openai.com/v1` | Any OpenAI-compatible `/chat/completions` base URL (Groq, OpenRouter, ...) |
| `OPENAI_MODEL_PLAN`             | `gpt-4o-mini`           | Model used for plans                     |
| `OPENAI_MODEL_TIP`              | `gpt-4o-mini`           | Model used for tips                      |
| `OPENAI_MODEL_FALLBACKS`        | `gpt-4o`                | Comma-separated fallback models for plans/tips |
| `SESSION_MAX_AGE_SEC`           | `604800`                 | 7 days                                  |
| `DAILY_GENERATION_QUOTA`        | `10`                     | New plans per user per day (revisions don't count) |
| `RATE_LIMIT_PER_MIN`            | `6`                      | Burst limiter for generation endpoints  |

## API

The API is served under `/api/v1` and uses the same signed session cookie as
the web UI. It is deliberately **not** CSRF-protected (that protection is for
forms); the `SameSite=Lax` cookie is the cross-site defence. Open
<http://localhost:8000/docs> and sign in via a normal web session first —
there is no bearer-token mode.

| Endpoint                          | Auth   | Purpose                                  |
| --------------------------------- | ------ | ---------------------------------------- |
| `GET  /api/v1/me`                 | user   | Current user profile                     |
| `GET  /api/v1/quota`              | user   | `remaining_today` for new plans           |
| `POST /api/v1/plans`              | user   | Generate a new plan (consumes quota)     |
| `GET  /api/v1/plans`              | user   | List my plans, newest first              |
| `GET  /api/v1/plans/{id}`         | user   | Fetch one of my plans                    |
| `GET  /api/v1/plans/{id}/revisions` | user | Full version history (chain), oldest first |
| `POST /api/v1/plans/{id}/revisions` | user | Create a revision from feedback         |
| `GET  /api/v1/tips?goal=...`      | user   | A cached nutrition/recovery tip          |
| `GET  /api/v1/admin/users`        | admin  | Paginated user list with plan counts     |
| `POST /api/v1/admin/users/{id}/delete` | admin | Delete a user (never yourself)          |
| `GET  /healthz`                   | public | Liveness + database + AI configuration   |

Every response uses a single error envelope:

```json
{ "error": { "code": "VALIDATION_ERROR", "message": "...", "field": "age", "request_id": "abc123" } }
```

Request ids are logged alongside details, so a user-reported error message can
be traced without exposing internals. Any error response may repeat an incoming
`X-Request-ID` header for correlation.

## Security posture

- Argon2 password hashing; timing-equalised responses for unknown accounts
  (no user enumeration via the login form).
- Signed session cookies; `HttpOnly`, `SameSite=Lax`, and `Secure` when
  `APP_ENV=production`. No server-side session state.
- CSRF tokens on every HTML form; the API relies on `SameSite=Lax`.
- SQLite enforces foreign keys on every connection (see
  `app/database.py:_sqlite_pragmas`) — deleting a user really cascades to
  their plans.
- Plan ownership is re-checked in the service layer, not just in routes, so an
  IDOR hole can't be reintroduced by a refactor.
- `extra="forbid"` on all input schemas: a posted `role`, `user_id`, or
  surprise field is rejected, not ignored.
- Plan and tip text is untrusted model output: HTML-escaped in templates,
  length-capped, and validated against a schema before storage.

## Tests

```bash
./venv/bin/python -m pytest        # 150 tests, ~7s
```

The suite uses a scratch SQLite database per run and stubs the AI layer at the
point of use, so it never needs a Gemini key or the network. Test doubles are
defined in `tests/conftest.py`; the migration tests run real `alembic`
upgrade → downgrade → upgrade cycles against a disposable database.

```bash
./venv/bin/ruff check app tests
./venv/bin/ruff format app tests --check
```

## Project layout

```
app/
  ai/          provider clients (Gemini + OpenAI-compatible), prompts, plan ai/          Gemini client, prompts (prompt/data separation), plan & tip logic tip logic
  routes/      web, auth, admin and /api/v1 JSON routes
  services/    user_service, plan_service, rate_limit  (business rules live here)
  models.py    User and the versioned Plan
  schemas.py   input/output Pydantic models + the Gemini JSON schema
  security.py  Argon2 hashing, sessions, CSRF, ownership checks
  errors.py    one error envelope for API and web alike
  cli.py       operator commands
alembic/       migrations (source of truth for the schema)
tests/         unit and API integration tests
```

## Known limits

- The gym background image is a placeholder (`static/images/gym-bg.jpg`); a
  CSS gradient shows until you drop in a licensed image at that path.
- Tips are generic per goal by design (the data we hold about a user is the
  profile in their latest plan, plus consent to use it for their generation
  history — we never train or share anything).
- `seed-demo` and `reset-db` accept no confirmation: they are development
  utilities, not production tooling.