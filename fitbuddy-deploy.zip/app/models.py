"""SQLAlchemy ORM models.

Design notes that differ from a naive first pass (see spec section 10.2):

* One row per plan **version**. Revisions never overwrite their parent, so the
  original stays byte-for-byte intact.
* ``version`` is monotonic per user, so ``(user_id, version)`` is a valid unique
  constraint even after a user generates a second original plan.
* ``profile_snapshot`` records the inputs a given version was generated from.
  Without it, editing a user's profile would silently rewrite the meaning of
  their plan history.
* ``content`` is JSON, not free text, so plans render and diff reliably.
"""

from __future__ import annotations

import datetime as dt
from typing import Any

from sqlalchemy import (
    JSON,
    CheckConstraint,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base
from app.enums import Goal, Intensity, PlanKind, Role


def _utcnow() -> dt.datetime:
    return dt.datetime.now(dt.UTC)


def _sa_enum(enum_class: type[Enum], length: int) -> Enum:
    """Build a column type that stores the enum *value*, not its member name.

    SQLAlchemy's default is to persist ``Member.NAME`` (``WEIGHT_LOSS``), which
    would put uppercase strings in the database and break the documented API
    contract. ``values_callable`` makes it store ``Member.value``
    (``weight_loss``) instead.
    """
    return Enum(
        enum_class,
        native_enum=False,
        length=length,
        validate_strings=True,
        values_callable=lambda members: [member.value for member in members],
    )


class User(Base):
    """An account. Only the password hash is stored, never the password."""

    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(320), nullable=False, unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    display_name: Mapped[str] = mapped_column(String(60), nullable=False)
    role: Mapped[Role] = mapped_column(_sa_enum(Role, length=10), nullable=False, default=Role.USER)

    # Profile inputs used as the basis for generation. Nullable because a user
    # can register before filling in their fitness profile.
    age: Mapped[int | None] = mapped_column(Integer, nullable=True)
    weight_kg: Mapped[float | None] = mapped_column(Float, nullable=True)
    goal: Mapped[Goal | None] = mapped_column(_sa_enum(Goal, length=20), nullable=True)
    intensity: Mapped[Intensity | None] = mapped_column(
        _sa_enum(Intensity, length=10), nullable=True
    )

    created_at: Mapped[dt.datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, server_default=func.now()
    )

    plans: Mapped[list[Plan]] = relationship(
        back_populates="user",
        cascade="all, delete-orphan",
        passive_deletes=True,
        order_by="Plan.version.desc()",
    )

    __table_args__ = (
        CheckConstraint("age IS NULL OR (age >= 16 AND age <= 90)", name="ck_users_age_range"),
        CheckConstraint(
            "weight_kg IS NULL OR (weight_kg >= 30.0 AND weight_kg <= 250.0)",
            name="ck_users_weight_range",
        ),
        Index("ix_users_created_at", "created_at"),
    )

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"<User id={self.id} role={self.role} email={self.email!r}>"

    @property
    def is_admin(self) -> bool:
        return self.role == Role.ADMIN


class Plan(Base):
    """One version of a workout plan."""

    __tablename__ = "plans"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )

    #: Monotonic per user. The first plan is v1; each revision takes the next number.
    version: Mapped[int] = mapped_column(Integer, nullable=False)

    #: NULL for an original plan, otherwise the plan this one revises.
    parent_plan_id: Mapped[int | None] = mapped_column(
        ForeignKey("plans.id", ondelete="CASCADE"), nullable=True, index=True
    )

    kind: Mapped[PlanKind] = mapped_column(
        _sa_enum(PlanKind, length=10), nullable=False, default=PlanKind.ORIGINAL
    )

    #: Why the user asked for a change. NULL for originals.
    feedback_text: Mapped[str | None] = mapped_column(Text, nullable=True)

    #: The validated plan, stored as structured JSON.
    content: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)

    #: The profile inputs this version was generated from.
    profile_snapshot: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)

    #: Short nutrition / recovery tip produced alongside the plan.
    tip: Mapped[str] = mapped_column(Text, nullable=False, default="")

    #: Provenance, so a stored plan can always be traced to the model/prompt that made it.
    model_name: Mapped[str] = mapped_column(String(64), nullable=False)
    prompt_version: Mapped[str] = mapped_column(String(32), nullable=False)

    created_at: Mapped[dt.datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, server_default=func.now()
    )

    user: Mapped[User] = relationship(back_populates="plans")

    __table_args__ = (
        UniqueConstraint("user_id", "version", name="uq_plans_user_version"),
        CheckConstraint("version >= 1", name="ck_plans_version_positive"),
        Index("ix_plans_user_created_at", "user_id", "created_at"),
    )

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"<Plan id={self.id} user_id={self.user_id} v{self.version} kind={self.kind}>"

    @property
    def is_original(self) -> bool:
        return self.kind == PlanKind.ORIGINAL

    @property
    def summary(self) -> str:
        """Short human-readable description used in listings."""
        summary = self.content.get("summary")
        return summary.strip() if isinstance(summary, str) and summary.strip() else "Workout plan"

    @property
    def training_days(self) -> int:
        """Number of non-rest days in the plan."""
        days = self.content.get("days") or []
        return sum(1 for day in days if not day.get("is_rest_day"))
