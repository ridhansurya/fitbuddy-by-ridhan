"""Registration, login and logout.

Note what is absent: there is no route anywhere that accepts a role, a user id,
or a plan id belonging to someone else from a submitted form.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse

from app.errors import AuthenticationError, ValidationError
from app.routes.form_utils import parse_form, repopulate
from app.schemas import LoginInput, RegisterInput
from app.security import CurrentUser, DbSession, login_session, logout_session, require_csrf
from app.services import user_service
from app.templating import render

logger = logging.getLogger(__name__)

router = APIRouter(tags=["auth"])

#: Values used only to render a blank, correctly-shaped form.
_REGISTER_DEFAULTS = {"display_name": "", "email": "", "password": ""}
_LOGIN_DEFAULTS = {"email": "", "password": ""}


def _post_redirect(url: str) -> RedirectResponse:
    """303, not 302: after a POST the browser must re-issue a GET."""
    return RedirectResponse(url=url, status_code=303)


def _safe_next(request: Request) -> str:
    """Only permit same-site relative redirects after login."""
    target = request.query_params.get("next") or "/"
    if not target.startswith("/") or target.startswith("//") or "\\" in target:
        return "/"
    return target


@router.get("/register", name="register_form")
def register_form(request: Request) -> object:
    return render(
        request.app.state.templates,
        request,
        "register.html",
        form=repopulate(RegisterInput, {}, **_REGISTER_DEFAULTS),
        errors={},
    )


@router.post("/register", dependencies=[Depends(require_csrf)])
async def register_submit(request: Request, db: DbSession) -> object:
    form_data = dict(await request.form())
    data, errors = parse_form(form_data, RegisterInput)

    if data is None:
        return render(
            request.app.state.templates,
            request,
            "register.html",
            status_code=422,
            form=repopulate(RegisterInput, form_data, **_REGISTER_DEFAULTS),
            errors=errors,
        )

    try:
        user = user_service.register_user(db, data)
    except ValidationError as exc:
        errors[exc.field or "form"] = exc.message
        return render(
            request.app.state.templates,
            request,
            "register.html",
            status_code=422,
            form=repopulate(RegisterInput, form_data, **_REGISTER_DEFAULTS),
            errors=errors,
        )

    login_session(request, user)
    request.session["flash"] = f"Welcome, {user.display_name}. Let's build your week."
    return _post_redirect("/")


@router.get("/login", name="login_form")
def login_form(request: Request) -> object:
    return render(
        request.app.state.templates,
        request,
        "login.html",
        form=repopulate(LoginInput, {}, **_LOGIN_DEFAULTS),
        errors={},
    )


@router.post("/login", dependencies=[Depends(require_csrf)])
async def login_submit(request: Request, db: DbSession) -> object:
    form_data = dict(await request.form())
    data, errors = parse_form(form_data, LoginInput)

    if data is None:
        return render(
            request.app.state.templates,
            request,
            "login.html",
            status_code=422,
            form=repopulate(LoginInput, form_data, **_LOGIN_DEFAULTS),
            errors=errors,
        )

    try:
        user = user_service.authenticate(db, data.email, data.password)
    except AuthenticationError as exc:
        return render(
            request.app.state.templates,
            request,
            "login.html",
            status_code=401,
            form=repopulate(LoginInput, form_data, **_LOGIN_DEFAULTS),
            errors={"password": exc.message},
        )

    login_session(request, user)
    request.session["flash"] = f"Signed in as {user.display_name}."
    return _post_redirect(_safe_next(request))


@router.post("/logout", dependencies=[Depends(require_csrf)])
def logout(request: Request, user: CurrentUser) -> RedirectResponse:
    logout_session(request)
    request.session["flash"] = "Signed out."
    logger.info("user_logged_out user_id=%s", user.id)
    return _post_redirect("/")
