"""Helpers for turning submitted HTML form data into validated models.

Forms need to do two things a JSON API does not: show the validation error
*next to the offending field* and redisplay what the user typed. These helpers
support both, so every form route handles failure the same way.
"""

from __future__ import annotations

from typing import Any, TypeVar

from pydantic import BaseModel
from pydantic import ValidationError as PydanticValidationError

ModelT = TypeVar("ModelT", bound=BaseModel)

#: What the field is called in the form versus the internal model attribute.
#: A form says "weight_kg"; we label it "weight".
_LABELS = {
    "display_name": "name",
    "weight_kg": "weight",
    "feedback": "feedback",
    "feedback_text": "feedback",
}


def _label(field: str | None) -> str:
    if not field:
        return "form"
    return _LABELS.get(field, field)


def _clean(message: str) -> str:
    """Strip Pydantic's 'Value error, ' prefix and capitalise for display."""
    text = message.removeprefix("Value error, ")
    return text[:1].upper() + text[1:] if text else "Invalid value"


def parse_form(
    form: dict[str, Any],
    model: type[ModelT],
    *,
    fields: tuple[str, ...] | None = None,
) -> tuple[ModelT | None, dict[str, str]]:
    """Validate ``form`` against ``model``.

    :param fields: the keys to read from the form. Defaults to the model's own
        field names, so a form cannot smuggle in an extra key.
    :returns: ``(validated, errors)``. Exactly one is meaningful: on success
        ``validated`` is set and ``errors`` is empty.
    """
    names = fields if fields is not None else tuple(model.model_fields)
    payload = {name: form.get(name) for name in names}
    # Absent optional fields must be omitted, not sent as None, so that
    # `notes: str | None` still validates.
    payload = {k: v for k, v in payload.items() if v is not None and v != ""}

    try:
        return model.model_validate(payload), {}
    except PydanticValidationError as exc:
        errors: dict[str, str] = {}
        for error in exc.errors():
            loc = [part for part in error.get("loc", ()) if part != "body"]
            key = _label(str(loc[-1]) if loc else None)
            errors.setdefault(key, _clean(str(error.get("msg", "Invalid value"))))
        return None, errors


def repopulate(model: type[ModelT], form: dict[str, Any], **defaults: Any) -> ModelT | None:
    """Rebuild a partially-invalid model so the form can be redisplayed.

    A validation error means at least one field is missing or wrong, so this
    returns a throwaway model built by skipping the missing field, and ``None``
    if even that is impossible. Templates must treat it as untrusted input.
    """
    for field in model.model_fields:
        if field not in defaults and field in form and form[field] != "":
            defaults[field] = form[field]
    for required in ("display_name", "email"):
        if required in defaults and not str(defaults[required]).strip():
            defaults[required] = " "

    try:
        return model.model_construct(**defaults)
    except Exception:
        return None
