"""JSON API under ``/api/v1``.

Mirrors the web features over the same service layer, which is what makes the
Swagger page at ``/docs`` a genuine test surface rather than decoration.

Authentication is the same signed session cookie the web UI uses. These routes
are CSRF-exempt by design (see :func:`app.security.require_csrf`) and rely on
``SameSite=Lax`` to block cross-site requests.
"""

from __future__ import annotations

import logging
from typing import Annotated

from fastapi import APIRouter, Query
from starlette.concurrency import run_in_threadpool

from app.ai.tips import generate_tip
from app.enums import Goal
from app.errors import PermissionDeniedError
from app.schemas import (
    AdminUserListOut,
    AdminUserRow,
    FeedbackInput,
    PlanCreatedOut,
    PlanOut,
    ProfileInput,
    TipOut,
    UserOut,
)
from app.security import AdminUser, CurrentUser, DbSession, get_plan_or_404, require_plan_owner
from app.services import plan_service, user_service
from app.services.rate_limit import remaining_generations

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["api"])


# ---------------------------------------------------------------------------
# Plans
# ---------------------------------------------------------------------------


@router.post("/plans", response_model=PlanCreatedOut, summary="Create a workout plan")
async def create_plan(payload: ProfileInput, db: DbSession, user: CurrentUser) -> PlanCreatedOut:
    """Generate a plan for the authenticated user.

    The user id comes from the session. ``ProfileInput`` forbids extra fields,
    so a ``user_id`` in the body is rejected with 422 rather than being trusted.
    """
    user_service.apply_profile(user, payload, db)
    plan = await run_in_threadpool(plan_service.create_plan, db, user, payload)
    created = PlanOut.from_model(plan)
    return PlanCreatedOut(**created.model_dump(), owner_display_name=user.display_name)


@router.get("/plans", response_model=list[PlanOut], summary="List the caller's plans")
def list_my_plans(db: DbSession, user: CurrentUser) -> list[PlanOut]:
    """Newest version first. Only ever returns the caller's own plans."""
    return [PlanOut.from_model(p) for p in plan_service.list_plans_for_user(db, user.id)]


@router.get("/plans/{plan_id}", response_model=PlanOut, summary="Fetch one plan")
def get_plan(plan_id: int, db: DbSession, user: CurrentUser) -> PlanOut:
    """A plan owned by someone else returns 404, not 403, so the app never
    confirms that another member's plan exists."""
    return PlanOut.from_model(get_plan_or_404(plan_id, db, user))


@router.get(
    "/plans/{plan_id}/revisions",
    response_model=list[PlanOut],
    summary="List every version of a plan, oldest first",
)
def list_revisions(plan_id: int, db: DbSession, user: CurrentUser) -> list[PlanOut]:
    """The full version family (the chain) containing ``plan_id``.

    A plan is immutable, so "history" means the original and every revision
    that descends from it, oldest first. The chain is asserted not to cross
    owners, so this never leaks another user's plans.
    """
    plan = get_plan_or_404(plan_id, db, user)
    return [PlanOut.from_model(p) for p in plan_service.plan_chain(db, plan)]


@router.post("/plans/{plan_id}/revisions", response_model=PlanOut, summary="Create a revision")
async def create_revision(
    plan_id: int, payload: FeedbackInput, db: DbSession, user: CurrentUser
) -> PlanOut:
    """Generate a new version from feedback. The parent row is never modified."""
    plan = get_plan_or_404(plan_id, db, user)
    require_plan_owner(plan, user)
    revision = await run_in_threadpool(plan_service.create_revision, db, user, plan, payload)
    return PlanOut.from_model(revision)


# ---------------------------------------------------------------------------
# Supporting data
# ---------------------------------------------------------------------------


@router.get("/tips", response_model=TipOut, summary="One nutrition or recovery tip")
async def get_tip(
    goal: Annotated[Goal, Query(description="Training goal")],
    user: CurrentUser,
) -> TipOut:
    """Cached per goal, so repeat calls cost nothing.

    Available to any signed-in user: the tip is identical for everyone sharing a
    goal, so there is nothing to authorise against.
    """
    tip, cached = await run_in_threadpool(generate_tip, goal)
    return TipOut(goal=goal, tip=tip, word_count=len(tip.split()), cached=cached)


@router.get("/quota", summary="How many new plans remain today")
def quota(db: DbSession, user: CurrentUser) -> dict[str, int]:
    return {"remaining_today": remaining_generations(db, user.id)}


@router.get("/me", response_model=UserOut, summary="The authenticated user")
def whoami(user: CurrentUser) -> UserOut:
    return UserOut.from_model(user)


# ---------------------------------------------------------------------------
# Admin
# ---------------------------------------------------------------------------


@router.get("/admin/users", response_model=AdminUserListOut, summary="All users (admin only)")
def admin_users(
    db: DbSession,
    admin: AdminUser,
    page: Annotated[int, Query(ge=1)] = 1,
    page_size: Annotated[int, Query(ge=1, le=100)] = 20,
    q: Annotated[str, Query(max_length=80, description="Search name or email")] = "",
) -> AdminUserListOut:
    rows, total = user_service.list_users_paginated(db, query=q, page=page, page_size=page_size)
    return AdminUserListOut(
        items=[
            AdminUserRow(
                user=UserOut.from_model(user),
                plan_count=count,
                latest_plan=PlanOut.from_model(latest) if latest else None,
                latest_version=latest.version if latest else None,
            )
            for user, count, latest in rows
        ],
        total=total,
        page=page,
        page_size=page_size,
        pages=max(1, -(-total // page_size)),
    )


@router.post("/admin/users/{user_id}/delete", summary="Delete a user (admin only)")
def admin_delete_user(user_id: int, db: DbSession, admin: AdminUser) -> dict[str, int]:
    if user_id == admin.id:
        raise PermissionDeniedError("You cannot delete the account you are signed in with.")
    user_service.delete_user(db, user_id)
    logger.info("admin_deleted_user actor_id=%s target_id=%s", admin.id, user_id)
    return {"deleted_user_id": user_id}
