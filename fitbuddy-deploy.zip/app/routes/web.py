"""Browser-facing routes: the profile form, generation, viewing and revising.

The Gemini call is blocking. Every handler that triggers one awaits
``run_in_threadpool`` so the event loop is never blocked, which means one slow
generation cannot stall other users' requests (spec finding D10).
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from starlette.concurrency import run_in_threadpool

from app.enums import PlanKind
from app.routes.form_utils import parse_form, repopulate
from app.schemas import FeedbackInput, ProfileInput, WorkoutPlan
from app.security import (
    CurrentUser,
    DbSession,
    OptionalUser,
    get_plan_or_404,
    require_csrf,
    require_plan_owner,
)
from app.services import plan_service, user_service
from app.services.rate_limit import remaining_generations
from app.templating import render

logger = logging.getLogger(__name__)

router = APIRouter(tags=["web"])

_PROFILE_DEFAULTS: dict[str, object] = {
    "display_name": "",
    "age": None,
    "weight_kg": None,
    "goal": None,
    "intensity": None,
    "notes": "",
}


async def form_fields(request: Request) -> dict[str, str]:
    """Read submitted form fields, keeping only scalar values.

    Starlette caches the parsed form, so this is cheap to call more than once.
    Uploaded files are dropped: this app has no file inputs.
    """
    form = await request.form()
    return {key: str(value) for key, value in form.items() if isinstance(value, str)}


# ---------------------------------------------------------------------------
# Home / profile form
# ---------------------------------------------------------------------------


@router.get("/", name="home")
async def home(request: Request, user: OptionalUser, db: DbSession) -> object:
    return await _render_home(request, user, db)


async def _render_home(
    request: Request,
    user: object,
    db: object,
    *,
    errors: dict[str, str] | None = None,
    submitted: dict[str, str] | None = None,
) -> object:
    """Render the profile form, prefilled from the saved profile when signed in."""
    prefill: ProfileInput | None = None
    plans_left: int | None = None

    if user is not None:
        if user.goal and user.intensity and user.age and user.weight_kg:
            prefill = ProfileInput(
                display_name=user.display_name,
                age=user.age,
                weight_kg=user.weight_kg,
                goal=user.goal,
                intensity=user.intensity,
            )
        plans_left = remaining_generations(db, user.id)

    if prefill is None and submitted:
        prefill = repopulate(ProfileInput, submitted, **_PROFILE_DEFAULTS)
    elif prefill is None:
        prefill = repopulate(ProfileInput, {}, **_PROFILE_DEFAULTS)

    return render(
        request.app.state.templates,
        request,
        "index.html",
        status_code=422 if errors else 200,
        form=prefill,
        errors=errors or {},
        flash=request.session.pop("flash", None),
        plans_left=plans_left,
    )


@router.post("/plans", name="create_plan", dependencies=[Depends(require_csrf)])
async def create_plan(request: Request, db: DbSession, user: CurrentUser) -> object:
    """Generate a plan from the submitted profile.

    The owner is always the session user. No form field can change that.
    """
    submitted = await form_fields(request)
    profile, errors = parse_form(submitted, ProfileInput)

    if profile is None:
        return await _render_home(request, user, db, errors=errors, submitted=submitted)

    # Persist the profile first so the history entry and the next visit agree.
    user_service.apply_profile(user, profile, db)

    plan = await run_in_threadpool(plan_service.create_plan, db, user, profile)
    request.session["flash"] = "Your 7-day plan is ready."
    return RedirectResponse(url=f"/plans/{plan.id}", status_code=303)


# ---------------------------------------------------------------------------
# Viewing and revising
# ---------------------------------------------------------------------------


@router.get("/plans/{plan_id}", name="view_plan")
def view_plan(request: Request, plan_id: int, db: DbSession, user: CurrentUser) -> object:
    plan = get_plan_or_404(plan_id, db, user)
    return _render_plan(request, db, user, plan, errors={}, feedback_text="")


def _render_plan(
    request: Request,
    db: object,
    user: object,
    plan: object,
    *,
    errors: dict[str, str],
    feedback_text: str,
) -> object:
    is_owner = plan.user_id == user.id
    all_plans = plan_service.list_plans_for_user(db, user.id) if is_owner else []

    return render(
        request.app.state.templates,
        request,
        "result.html",
        status_code=422 if errors else 200,
        plan=plan,
        content=WorkoutPlan.model_validate(plan.content),
        owner_name=plan_owner_name(db, plan),
        chain=plan_service.plan_chain(db, plan),
        revisions=[p for p in all_plans if p.parent_plan_id == plan.id],
        is_owner=is_owner,
        can_revise=is_owner,
        flash=request.session.pop("flash", None),
        errors=errors,
        feedback_text=feedback_text,
        plan_kind_label=PlanKind(plan.kind).label,
    )


def plan_owner_name(db: object, plan: object) -> str:
    from app.models import User

    owner = db.get(User, plan.user_id)
    return owner.display_name if owner else "Unknown"


@router.post(
    "/plans/{plan_id}/feedback",
    name="submit_feedback",
    dependencies=[Depends(require_csrf)],
)
async def submit_feedback(
    request: Request, plan_id: int, db: DbSession, user: CurrentUser
) -> object:
    """Create a new plan version from feedback. The parent row is never modified."""
    plan = get_plan_or_404(plan_id, db, user)
    require_plan_owner(plan, user)

    submitted = await form_fields(request)
    feedback, errors = parse_form(submitted, FeedbackInput)

    if feedback is None:
        return _render_plan(
            request, db, user, plan, errors=errors, feedback_text=submitted.get("feedback", "")
        )

    revision = await run_in_threadpool(plan_service.create_revision, db, user, plan, feedback)
    request.session["flash"] = "Here's your revised plan. The original is untouched."
    return RedirectResponse(url=f"/plans/{revision.id}", status_code=303)


@router.get("/my-plans", name="my_plans")
def my_plans(request: Request, db: DbSession, user: CurrentUser) -> object:
    plans = plan_service.list_plans_for_user(db, user.id)
    return render(
        request.app.state.templates,
        request,
        "my_plans.html",
        plans=plans,
        flash=request.session.pop("flash", None),
    )
