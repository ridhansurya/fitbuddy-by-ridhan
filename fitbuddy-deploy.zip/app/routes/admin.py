"""Coach/admin routes.

Every handler depends on ``AdminUser``, which is ``require_admin`` composed on
top of ``get_current_user``. That is the direct fix for the unauthenticated
admin page in the original proof of concept (spec finding S1).

Coaches may read anything and delete accounts; they may not edit plan content.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse

from app.schemas import WorkoutPlan
from app.security import AdminUser, DbSession, require_csrf
from app.services import plan_service, user_service
from app.templating import render

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/admin", tags=["admin"])

MAX_PAGE_SIZE = 100


@router.get("/users", name="admin_users")
def list_users(
    request: Request,
    db: DbSession,
    admin: AdminUser,
    page: int = 1,
    page_size: int = 20,
    q: str = "",
) -> object:
    """Searchable, paginated list of every user with their latest plan."""
    page = max(1, page)
    page_size = max(1, min(page_size, MAX_PAGE_SIZE))

    rows, total = user_service.list_users_paginated(
        db, query=q[:80], page=page, page_size=page_size
    )
    pages = max(1, -(-total // page_size))

    entries = [
        {
            "user": user,
            "plan_count": count,
            "latest": latest,
            "latest_content": WorkoutPlan.model_validate(latest.content) if latest else None,
            "original": plan_service.chain_root(db, latest) if latest else None,
        }
        for user, count, latest in rows
    ]

    return render(
        request.app.state.templates,
        request,
        "all_users.html",
        entries=entries,
        total=total,
        page=page,
        page_size=page_size,
        pages=pages,
        q=q,
        flash=request.session.pop("flash", None),
    )


@router.post(
    "/users/{user_id}/delete", name="admin_delete_user", dependencies=[Depends(require_csrf)]
)
def delete_user(
    user_id: int, request: Request, db: DbSession, admin: AdminUser
) -> RedirectResponse:
    """Delete an account and, by cascade, all of its plans.

    An admin cannot delete their own account, which would lock everyone out of
    this page.
    """
    if user_id == admin.id:
        request.session["flash"] = "You can't delete your own account."
        return RedirectResponse(url="/admin/users", status_code=303)

    user_service.delete_user(db, user_id)
    request.session["flash"] = f"Account {user_id} and its plans were deleted."
    logger.info("admin_deleted_user actor_id=%s target_id=%s", admin.id, user_id)
    return RedirectResponse(url="/admin/users", status_code=303)
