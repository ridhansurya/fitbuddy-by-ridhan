"""Plan generation and revision.

Two bounded, single-shot calls per user action. No agent loop, no tool calling,
no multi-step planning - the whole design is explainable in one sentence, which
is the point.
"""

from __future__ import annotations

import logging
from typing import Any

from app.ai.client import get_client
from app.ai.prompts import (
    PLAN_SYSTEM_INSTRUCTION,
    REVISION_SYSTEM_INSTRUCTION,
    plan_generation_prompt,
    plan_revision_prompt,
)
from app.config import get_settings
from app.errors import AIServiceError
from app.schemas import ProfileInput, WorkoutPlan, plan_json_schema

logger = logging.getLogger(__name__)


def _generate_with_fallback(
    *,
    settings_models: tuple[str, ...],
    system_instruction: str,
    user_prompt: str,
) -> tuple[WorkoutPlan, str]:
    """One plan-shaped call, walking the configured model candidates.

    The free tier throttles models independently (503 high demand, 429 quota),
    so if the primary model's transport call fails we try the next candidate
    rather than showing the user an error. Output validation is unchanged: a
    response is only ever accepted as a real plan by the exact same schema gate,
    whichever candidate produced it.
    """
    client = get_client()
    last_error: AIServiceError | None = None
    for model in settings_models:
        try:
            plan = client.generate_json(
                model=model,
                system_instruction=system_instruction,
                user_prompt=user_prompt,
                schema=WorkoutPlan,
                json_schema=plan_json_schema(),
            )
            if settings_models[-1] != model:
                logger.info("plan_generation_used_fallback model=%s", model)
            return plan, model
        except AIServiceError as exc:
            last_error = exc
            logger.warning("plan_generation_model_failed model=%s", model)
    raise last_error if last_error is not None else AIServiceError()


def generate_plan(profile: ProfileInput) -> tuple[WorkoutPlan, str]:
    """Generate a fresh 7-day plan. Returns ``(plan, model_name)``."""
    settings = get_settings()
    plan, model = _generate_with_fallback(
        settings_models=tuple(settings.plan_model_candidates),
        system_instruction=PLAN_SYSTEM_INSTRUCTION,
        user_prompt=plan_generation_prompt(profile),
    )
    logger.info(
        "plan_generated model=%s training_days=%d rest_days=%d",
        model,
        len(plan.training_days),
        plan.rest_day_count,
    )
    return plan, model


def revise_plan(
    profile: ProfileInput, previous_plan: dict[str, Any], feedback: str
) -> tuple[WorkoutPlan, str]:
    """Generate a new version of a plan from the previous plan plus feedback.

    The previous plan is passed through ``WorkoutPlan`` validation first, so a
    corrupt stored row fails loudly here instead of confusing the model.
    """
    settings = get_settings()
    # Re-validate before sending: never feed unvalidated JSON to the model.
    validated_previous = WorkoutPlan.model_validate(previous_plan)

    plan, model = _generate_with_fallback(
        settings_models=tuple(settings.plan_model_candidates),
        system_instruction=REVISION_SYSTEM_INSTRUCTION,
        user_prompt=plan_revision_prompt(profile, validated_previous.model_dump(), feedback),
    )

    # A revision identical to its parent means the model ignored the request.
    # Logged so a quality problem shows up in the server log rather than as a
    # user quietly receiving their old plan back.
    unchanged = plan == validated_previous
    if unchanged:
        logger.warning("revision_matched_previous feedback_len=%d", len(feedback))

    logger.info(
        "plan_revised model=%s training_days=%d rest_days=%d unchanged=%s",
        model,
        len(plan.training_days),
        plan.rest_day_count,
        unchanged,
    )
    return plan, model
