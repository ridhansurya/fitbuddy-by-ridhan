"""Thin wrappers around the AI providers.

Everything that makes a raw provider call awkward lives here: the API key, the
timeout, the retry-on-invalid-output behaviour, fenced-JSON extraction, and
turning provider errors into our own typed exceptions.

Two providers share one contract:

- :class:`GeminiClient` talks to Google Gemini (structured output supported).
- :class:`OpenAICompatibleClient` talks to any OpenAI-style ``/chat/completions``
  endpoint (OpenAI, Groq, OpenRouter, ...) and uses JSON mode plus local
  validation - the model is never trusted to produce exactly valid JSON, the
  ``schema.model_validate`` gate decides that.

Clients are created lazily and cached, so importing this module never requires
an API key. That is what lets the app boot (and the test suite run) with no key
configured.
"""

from __future__ import annotations

import json
import logging
import re
import threading
from typing import Any, TypeVar

from pydantic import BaseModel
from pydantic import ValidationError as PydanticValidationError

from app.config import get_settings
from app.errors import AIResponseError, AIServiceError

logger = logging.getLogger(__name__)

ModelT = TypeVar("ModelT", bound=BaseModel)

#: Transport-level error statuses worth retrying across models. 4xx below 429
#: means the request itself is wrong and will stay wrong.
_RETRYABLE_STATUS = frozenset({408, 429, 500, 502, 503, 504})

_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*(?P<body>.*?)\s*```\s*$", re.DOTALL)

#: Models confirmed (by a 400) to reject a JSON schema. Calls to them skip the
#: schema attempt entirely, saving one round-trip and quota burn. Reset naturally
#: when the process restarts; capabilities can change.
_NO_SCHEMA_MODELS: set[str] = set()


class _SchemaRejected(Exception):
    """Internal: the provider refused the JSON-schema request (bare 400)."""


class BaseAIClient:
    """Shared validation, retry and schema-fallback logic.

    ``generate_text`` and ``generate_json`` are the public contract every
    caller uses. Providers implement ``_raw_generate``; this base class decides
    whether a schema is worth sending and recovers when it is not.
    """

    def _generate(
        self,
        *,
        model: str,
        system_instruction: str,
        user_prompt: str,
        json_schema: dict[str, Any] | None,
        max_output_tokens: int,
        plain_json_fallback: bool = False,
    ) -> str:
        """One provider call, retrying once without the schema if refused."""
        send_schema = json_schema is not None and model not in _NO_SCHEMA_MODELS
        try:
            return self._raw_generate(
                model=model,
                system_instruction=system_instruction,
                user_prompt=user_prompt,
                json_schema=json_schema if send_schema else None,
                max_output_tokens=max_output_tokens,
            )
        except _SchemaRejected:
            if not (plain_json_fallback and json_schema is not None):
                raise
            # Remember the rejection so later calls skip the schema attempt
            # entirely - the 400 round-trip costs time and quota.
            _NO_SCHEMA_MODELS.add(model)
            logger.warning("schema_rejected retrying_without_schema model=%s", model)
            return self._raw_generate(
                model=model,
                system_instruction=system_instruction,
                user_prompt=user_prompt,
                json_schema=None,
                max_output_tokens=max_output_tokens,
            )

    def _raw_generate(
        self,
        *,
        model: str,
        system_instruction: str,
        user_prompt: str,
        json_schema: dict[str, Any] | None,
        max_output_tokens: int,
    ) -> str:
        raise NotImplementedError

    # -- public API -------------------------------------------------------

    def generate_text(
        self,
        *,
        model: str,
        system_instruction: str,
        user_prompt: str,
        max_output_tokens: int = 1024,
    ) -> str:
        """Plain text completion, no schema."""
        return self._generate(
            model=model,
            system_instruction=system_instruction,
            user_prompt=user_prompt,
            json_schema=None,
            max_output_tokens=max_output_tokens,
        ).strip()

    def generate_json(
        self,
        *,
        model: str,
        system_instruction: str,
        user_prompt: str,
        schema: type[ModelT],
        json_schema: dict[str, Any],
        max_output_tokens: int = 4096,
    ) -> ModelT:
        """Return a validated model instance, retrying once on invalid output.

        The retry exists because model output occasionally comes back with one
        field wrong. Per the spec, exactly one retry, then a friendly error.
        The failure is raised, never returned - so an unusable response can
        never be persisted as if it were a plan.
        """
        last_error: str = "unknown"

        for attempt in (1, 2):
            # On the retry, tell the model what was rejected so it can fix it.
            # Open models on provider fleets (e.g. Groq) routinely get one field
            # wrong; a blind identical retry would just repeat the mistake. The
            # spec's "exactly one retry" still holds - this is that one retry.
            prompt = user_prompt
            if attempt == 2 and last_error != "unknown":
                prompt = (
                    f"{user_prompt}\n\nThe JSON you returned before was rejected "
                    f"with: {last_error}\nReturn a corrected JSON object only."
                )

            raw = self._generate(
                model=model,
                system_instruction=system_instruction,
                user_prompt=prompt,
                json_schema=json_schema,
                plain_json_fallback=True,
                max_output_tokens=max_output_tokens,
            )

            try:
                return schema.model_validate(_parse_json(raw))
            except (PydanticValidationError, ValueError) as exc:
                last_error = str(exc)[:400]
                logger.warning(
                    "ai_schema_validation_failed attempt=%s detail=%s", attempt, last_error
                )
                if attempt == 1:
                    logger.info("retrying_once_after_invalid_output")

        raise AIResponseError()


class GeminiClient(BaseAIClient):
    """Google Gemini, via the Chat surface (the 3.x Flash family needs it)."""

    def __init__(self, api_key: str, timeout_sec: float) -> None:
        from google import genai  # imported lazily: heavy, and optional

        self._timeout_sec = timeout_sec
        self._client = genai.Client(
            api_key=api_key,
            http_options={"timeout": int(timeout_sec) * 1000},
        )

    def _raw_generate(
        self,
        *,
        model: str,
        system_instruction: str,
        user_prompt: str,
        json_schema: dict[str, Any] | None,
        max_output_tokens: int,
    ) -> str:
        from google.genai import types

        config_kwargs: dict[str, Any] = {
            "system_instruction": system_instruction,
            "temperature": 0.7,
            "max_output_tokens": max_output_tokens,
            "response_mime_type": "application/json",
        }
        if json_schema is not None:
            config_kwargs["response_json_schema"] = sanitise_json_schema(json_schema)

        config = types.GenerateContentConfig(**config_kwargs)

        try:
            # A fresh one-shot chat per request keeps the "single-shot" contract.
            chat = self._client.chats.create(model=model, config=config)
            response = chat.send_message(user_prompt)
        # The SDK raises a wide range of exception types; all are translated below.
        except Exception as exc:
            if json_schema is not None and _is_invalid_argument(exc):
                raise _SchemaRejected from exc
            raise self._translate(exc) from exc

        text = getattr(response, "text", None)
        if not text or not text.strip():
            logger.warning("gemini_empty_response model=%s", model)
            raise AIResponseError
        return text

    def _translate(self, exc: Exception) -> AIServiceError:
        """Map a provider exception onto one of our own, keeping detail in logs."""
        name = type(exc).__name__
        status = getattr(exc, "code", None) or getattr(exc, "status_code", None)
        logger.warning("gemini_call_failed exc=%s status=%s", name, status)

        if name in {"ClientError", "APIError"} and status in _RETRYABLE_STATUS:
            return AIServiceError("The plan generator is busy right now. Please try again.")
        if name in {"ResourceExhausted", "ClientError"} and status == 429:
            return AIServiceError("The plan generator is busy right now. Please try again.")
        if name in {"DeadlineExceeded", "TimeoutError"}:
            return AIServiceError("The plan generator took too long to respond. Please try again.")
        if name in {"ServerError", "ServiceUnavailable"}:
            return AIServiceError("The plan generator is unavailable right now.")
        if name == "Unauthenticated":
            return AIServiceError("The AI service rejected our API key. Check the server config.")
        if name in {"ClientError", "BadRequest"}:
            return AIServiceError("The plan generator rejected the request.")
        return AIServiceError()


class OpenAICompatibleClient(BaseAIClient):
    """Any OpenAI-style ``/chat/completions`` endpoint (OpenAI, Groq, OpenRouter).

    These APIs offer JSON mode but not JSON-schema enforcement, so the schema
    is never sent. The response is validated by the exact same gate
    (``schema.model_validate``) as Gemini, and retried once per the spec - the
    plan a user sees is always a fully validated one.
    """

    def __init__(self, api_key: str, base_url: str, timeout_sec: float) -> None:
        import httpx  # imported lazily: only needed when this provider is used

        self._timeout_sec = timeout_sec
        self._auth = {"Authorization": f"Bearer {api_key}"}
        self._endpoint = f"{base_url.rstrip('/')}/chat/completions"
        self._http = httpx.Client(timeout=timeout_sec)

    def _raw_generate(
        self,
        *,
        model: str,
        system_instruction: str,
        user_prompt: str,
        json_schema: dict[str, Any] | None,
        max_output_tokens: int,
    ) -> str:
        payload: dict[str, Any] = {
            "model": model,
            "messages": [
                {"role": "system", "content": system_instruction},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.7,
            "max_tokens": max_output_tokens,
        }
        if json_schema is not None:
            payload["response_format"] = {"type": "json_object"}

        try:
            response = self._http.post(self._endpoint, headers=self._auth, json=payload)
        except Exception as exc:
            import httpx

            logger.warning("openai_call_failed exc=%s model=%s", type(exc).__name__, model)
            if isinstance(exc, httpx.TimeoutException):
                raise AIServiceError(
                    "The plan generator took too long to respond. Please try again."
                ) from exc
            raise AIServiceError("The plan generator is unavailable right now.") from exc

        status = response.status_code
        if status != 200:
            logger.warning(
                "openai_http_error status=%s body=%s model=%s",
                status,
                response.text[:200],
                model,
            )
            if status >= 500 or status in (408, 429):
                raise AIServiceError("The plan generator is busy right now. Please try again.")
            if status in (401, 403):
                raise AIServiceError(
                    "The AI service rejected our API key. Check the server config."
                )
            if json_schema is not None and status == 400:
                raise _SchemaRejected
            raise AIServiceError("The plan generator rejected the request.")

        try:
            body = response.json()
            content = (body["choices"][0]["message"]["content"] or "").strip()
        except (ValueError, KeyError, IndexError) as exc:
            logger.warning("openai_unparseable_response model=%s", model)
            raise AIResponseError from exc
        if not content:
            logger.warning("openai_empty_response model=%s", model)
            raise AIResponseError
        return content

    def close(self) -> None:
        self._http.close()


#: JSON-Schema keywords Gemini's structured-output mode rejects. Kept to the
#: minimal set we actually emit; the comment in :func:`sanitise_json_schema`
#: explains why dropping them is safe.
_UNSUPPORTED_JSON_SCHEMA_KEYS = frozenset(
    {
        # Gemini's JSON-mode validation rejects these outright with a bare
        # INVALID_ARGUMENT. Pydantic still enforces them locally (extra="forbid"
        # is checked by schema.model_validate), so dropping them from the wire
        # copy costs nothing.
        "additionalProperties",
        "title",
    }
)


def sanitise_json_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """Copy ``schema`` minus the keys Gemini's JSON mode refuses.

    JSON Schema syntax like ``additionalProperties`` is correct JSON Schema but
    not part of the subset the Gemini API accepts for structured output; some
    models answer with an unhelpful generic 400. The authoritative gate remains
    ``schema.model_validate`` in :meth:`BaseAIClient.generate_json`, so removing
    these keywords from the *request* cannot make a forbidden field pass later.
    """
    if not isinstance(schema, dict):
        return schema

    cleaned: dict[str, Any] = {}
    for key, value in schema.items():
        if key in _UNSUPPORTED_JSON_SCHEMA_KEYS:
            continue
        if isinstance(value, dict):
            value = sanitise_json_schema(value)
        elif isinstance(value, list):
            value = [
                sanitise_json_schema(item) if isinstance(item, dict) else item for item in value
            ]
        cleaned[key] = value
    return cleaned


def _is_invalid_argument(exc: BaseException) -> bool:
    """True when a provider error is a 400 the exact retry path can fix."""
    name = type(exc).__name__
    status = getattr(exc, "code", None) or getattr(exc, "status_code", None)
    return status in (400,) or name in {"ClientError", "BadRequest", "InvalidArgument"}


def _parse_json(raw: str) -> Any:
    """Extract a JSON object from a model response.

    With ``response_mime_type='application/json'`` the body should already be
    raw JSON. Fenced blocks are still handled because models occasionally add
    them anyway, and a parse failure here would otherwise cost a paid retry.
    """
    text = raw.strip()
    fenced = _FENCE_RE.match(text)
    if fenced:
        text = fenced.group("body").strip()
    return json.loads(text)


_client_gemini: GeminiClient | None = None
_client_openai: OpenAICompatibleClient | None = None
_client_lock = threading.Lock()


def get_client() -> BaseAIClient:
    """Return the shared client for the active provider, or raise if not configured."""
    settings = get_settings()
    if not settings.ai_available:
        raise AIServiceError("The plan generator isn't configured on this server.")

    global _client_gemini, _client_openai
    if settings.ai_provider == "openai":
        if _client_openai is None:
            with _client_lock:
                if _client_openai is None:
                    _client_openai = OpenAICompatibleClient(
                        api_key=settings.openai_api_key,
                        base_url=settings.openai_base_url,
                        timeout_sec=settings.gemini_timeout_sec,
                    )
        return _client_openai

    if _client_gemini is None:
        with _client_lock:
            if _client_gemini is None:
                _client_gemini = GeminiClient(
                    api_key=settings.gemini_api_key, timeout_sec=settings.gemini_timeout_sec
                )
    return _client_gemini


def reset_client() -> None:
    """Drop the cached clients. Test-only."""
    global _client_gemini, _client_openai
    with _client_lock:
        _client_gemini = None
        _client_openai = None
