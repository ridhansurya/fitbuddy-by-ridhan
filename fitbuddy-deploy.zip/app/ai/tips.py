"""Short nutrition and recovery tips.

Tips depend only on the goal, so the same result would be produced repeatedly.
They are cached in-process with a TTL, which removes most of the cost of the
feature without introducing a cache server (spec section 9.5).
"""

from __future__ import annotations

import logging
import re
import threading
import time

from app.ai.client import get_client
from app.ai.prompts import MAX_TIP_WORDS, TIP_SYSTEM_INSTRUCTION, tip_prompt
from app.config import get_settings
from app.enums import Goal
from app.errors import AIResponseError, AppError

logger = logging.getLogger(__name__)

#: Tips are generic enough to stay valid for a long time.
CACHE_TTL_SEC = 24 * 60 * 60

#: Unwanted formatting the model adds despite being asked not to.
_LEADING_RE = re.compile(r"^[\s>*\-\u2022#]+", re.MULTILINE)
#: Emphasis characters anywhere in the text. Stripped globally rather than only
#: at the ends, because a mid-sentence ``**`` would otherwise render literally.
_EMPHASIS_RE = re.compile(r"[*_`]")
# Curly quotes the model sometimes adds, written as escapes to stay ASCII.
_QUOTES_RE = re.compile('^["\u201c\u2018]|["\u201d\u2019]$')


class _TipCache:
    """Small thread-safe TTL cache keyed by goal."""

    def __init__(self, ttl_sec: int) -> None:
        self.ttl_sec = ttl_sec
        self._entries: dict[str, tuple[float, str]] = {}
        self._lock = threading.Lock()

    def get(self, key: str) -> str | None:
        with self._lock:
            entry = self._entries.get(key)
            if entry is None:
                return None
            stored_at, value = entry
            if time.monotonic() - stored_at > self.ttl_sec:
                del self._entries[key]
                return None
            return value

    def put(self, key: str, value: str) -> None:
        with self._lock:
            self._entries[key] = (time.monotonic(), value)

    def clear(self) -> None:
        with self._lock:
            self._entries.clear()


cache = _TipCache(ttl_sec=CACHE_TTL_SEC)


def generate_tip(goal: Goal) -> tuple[str, bool]:
    """Return ``(tip, was_cached)`` for a goal.

    A tip failure is never fatal: the plan is the product, the tip is a bonus.
    Every expected failure - no API key, provider outage, unusable output -
    falls back to a short static tip, so a tip problem can never take down plan
    generation.
    """
    cached = cache.get(goal.value)
    if cached is not None:
        return cached, True

    # A tip failure is never fatal: the plan is the product, the tip is a bonus.
    # Walk the configured model candidates, then fall back to a static tip.
    last_code: str = "UNKNOWN"
    for model in get_settings().plan_model_candidates:
        try:
            raw = get_client().generate_text(
                model=model,
                system_instruction=TIP_SYSTEM_INSTRUCTION,
                user_prompt=tip_prompt(goal.value),
                max_output_tokens=180,
            )
        except AppError as exc:
            last_code = exc.code
            continue
        try:
            tip = _normalise_tip(raw)
        except AppError:
            continue
        cache.put(goal.value, tip)
        return tip, False

    logger.warning("tip_generation_failed goal=%s code=%s", goal.value, last_code)
    return _FALLBACK_TIPS[goal], False


def _normalise_tip(raw: str) -> str:
    """Strip formatting and enforce the word limit from the acceptance criteria."""
    text = raw.strip()
    text = _LEADING_RE.sub("", text)
    text = _EMPHASIS_RE.sub("", text)
    text = _QUOTES_RE.sub("", text)
    text = " ".join(text.split())

    words = text.split()
    if not words:
        raise AIResponseError
    if len(words) > MAX_TIP_WORDS:
        # Safety net: the prompt asks for at most 60 words, so this rarely fires.
        text = " ".join(words[:MAX_TIP_WORDS]).rstrip(",;:.") + "."
    return text


def clear_cache() -> None:
    """Empty the tip cache. Test-only."""
    cache.clear()


#: Used only when the AI tip call fails. Generic, safe, goal-appropriate, and
#: short enough to satisfy the <= 60 word acceptance criterion on its own.
_FALLBACK_TIPS: dict[Goal, str] = {
    Goal.WEIGHT_LOSS: (
        "Eat regular meals built around protein and whole foods rather than "
        "skipping meals to lose weight faster. Steady habits matter far more "
        "than any single trick, and your plan is doing the heavy lifting."
    ),
    Goal.MUSCLE_GAIN: (
        "Aim to eat a little more than you currently do, spread across the day, "
        "and get enough protein each meal to support repair. Consistency across "
        "weeks matters more than any single session."
    ),
    Goal.ENDURANCE: (
        "Prioritise sleep and easy-to-digest meals, especially around longer "
        "sessions. Fuel with familiar foods you have trained on before rather "
        "than trying anything new on a hard day."
    ),
    Goal.GENERAL_FITNESS: (
        "Keep meals simple and regular, and treat hydration as part of the "
        "workout. Small repeatable habits compound far better than short bursts "
        "of effort followed by a break."
    ),
    Goal.FLEXIBILITY: (
        "Warm up gently before stretching and keep water nearby - mobility work "
        "improves most when it is frequent and unhurried, not when it is pushed "
        "to a painful range."
    ),
}
