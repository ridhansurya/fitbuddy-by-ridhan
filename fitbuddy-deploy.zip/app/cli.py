"""Administrative commands.

Admin accounts are created here rather than through the signup form, so there
is no public way to grant yourself the admin role.

    python -m app.cli create-admin --email coach@fitbuddy.dev --password 'strong-pass-1'
    python -m app.cli seed-demo
    python -m app.cli list-users
"""

from __future__ import annotations

import argparse
import sys

from sqlalchemy import select

from app.config import get_settings
from app.database import Base, get_engine, get_sessionmaker
from app.enums import Goal, Intensity, PlanKind, Role
from app.errors import ConflictError
from app.models import Plan, User
from app.schemas import Exercise, PlanDay, ProfileInput, Warmup, WorkoutPlan
from app.security import find_user_by_email, hash_password
from app.services import user_service

DEMO_PASSWORD = "demopass123"


def _ensure_schema() -> None:
    """Create tables if the CLI is run before the first migration.

    Alembic remains the source of truth; this only makes the CLI usable on a
    brand-new checkout without a separate manual step.
    """
    Base.metadata.create_all(get_engine())


def _make_user(db, email: str, password: str, display_name: str, role: Role) -> User:
    existing = find_user_by_email(db, email)
    if existing is not None:
        raise ConflictError(f"{email} already exists (id={existing.id}).")
    user = User(
        email=email,
        password_hash=hash_password(password),
        display_name=display_name,
        role=role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def cmd_create_admin(args: argparse.Namespace) -> int:
    _ensure_schema()
    with get_sessionmaker()() as db:
        user = _make_user(db, args.email, args.password, args.name, Role.ADMIN)
        print(f"Created admin: {user.display_name} <{user.email}> (id={user.id})")
    return 0


def cmd_list_users(args: argparse.Namespace) -> int:
    with get_sessionmaker()() as db:
        users = db.scalars(select(User).order_by(User.id))
        for user in users:
            print(f"{user.id:>4}  {user.role:<5}  {user.email:<28}  {user.display_name}")
        if not users:
            print("No users yet.")
    return 0


def _sample_plan(profile: ProfileInput) -> WorkoutPlan:
    """A deterministic, schema-valid plan used to give the dashboard content.

    This is demo data, not model output: no API call, so ``seed-demo`` works
    offline and instantly.
    """
    focus_by_day = [
        "Full body foundation",
        "Upper body strength",
        "Active recovery",
        "Lower body strength",
        "Cardio conditioning",
        "Core and stability",
        "Rest and reflect",
    ]
    exercises_by_day = [
        ["Bodyweight squat", "Push-up", "Glute bridge", "Plank"],
        ["Push-up", "Pike push-up", "Row (towel or band)", "Dead bug"],
        [],
        ["Walking lunges", "Glute bridge", "Calf raise", "Side plank"],
        ["High knees", "Mountain climbers", "Burpee", "Jump rope"],
        ["Bird dog", "Dead bug", "Forearm plank", "Side plank"],
        [],
    ]

    days = []
    for index, focus in enumerate(focus_by_day, start=1):
        names = exercises_by_day[index - 1]
        is_rest = not names
        days.append(
            PlanDay(
                day=index,
                focus=focus,
                is_rest_day=is_rest,
                warmup=Warmup(
                    duration_min=8 if not is_rest else 5,
                    items=["Arm circles", "Jumping jacks", "Leg swings"]
                    if not is_rest
                    else ["Easy walk"],
                ),
                exercises=[
                    Exercise(name=name, sets=3, reps="10-12", rest_sec=60) for name in names
                ],
                cooldown="Slow breathing and light stretching, 5-10 minutes",
            )
        )

    return WorkoutPlan(
        summary=(
            f"A {profile.intensity.value}-intensity week built around your goal of "
            f"{profile.goal.label.lower()}. Six days of movement with one full rest day, "
            "progressing gradually."
        ),
        days=days,
        notes=[
            "Start every set with controlled form rather than speed.",
            "Stop any exercise that causes sharp pain.",
            "Increase reps by 2 next week if every set felt easy.",
        ],
    )


def _tip_for(goal: Goal) -> str:
    return {
        Goal.WEIGHT_LOSS: (
            "Eat regular meals built around protein and whole foods rather than skipping "
            "meals to lose weight faster. Steady habits matter far more than any single trick."
        ),
        Goal.MUSCLE_GAIN: (
            "Eat a little more than you currently do and get enough protein at each meal "
            "to support repair. Consistency across weeks beats any single hard session."
        ),
        Goal.ENDURANCE: (
            "Prioritise sleep, and fuel with familiar foods you have trained on before "
            "rather than trying anything new on a hard day."
        ),
        Goal.GENERAL_FITNESS: (
            "Keep meals simple and regular, and treat hydration as part of the workout. "
            "Small repeatable habits compound far better than short bursts of effort."
        ),
        Goal.FLEXIBILITY: (
            "Warm up gently before stretching and keep water nearby. Mobility work improves "
            "most when it is frequent and unhurried, not pushed to a painful range."
        ),
    }[goal]


def cmd_seed_demo(args: argparse.Namespace) -> int:
    """Create an admin, two members, and a small amount of plan history.

    The second member gets an original plan *and* a revision, so the admin
    dashboard has a real original-vs-revised comparison to show.
    """
    from app.ai.prompts import PROMPT_VERSION

    _ensure_schema()
    settings = get_settings()
    db = get_sessionmaker()()

    try:
        coach = _make_user(db, args.admin_email, DEMO_PASSWORD, "Coach Priya", Role.ADMIN)

        members = [
            (
                "asha@demo.dev",
                "Asha Raman",
                ProfileInput(
                    display_name="Asha Raman",
                    age=27,
                    weight_kg=58.0,
                    goal=Goal.MUSCLE_GAIN,
                    intensity=Intensity.MEDIUM,
                    notes="Desk job, training at home with no equipment.",
                ),
                ["add more cardio", "make day 4 lighter, my knees get tired"],
            ),
            (
                "karthik@demo.dev",
                "Karthik Subramanian",
                ProfileInput(
                    display_name="Karthik Subramanian",
                    age=34,
                    weight_kg=82.0,
                    goal=Goal.WEIGHT_LOSS,
                    intensity=Intensity.LOW,
                    notes=None,
                ),
                ["a bit more cardio please"],
            ),
        ]

        for email, name, profile, feedback_list in members:
            user = _make_user(db, email, DEMO_PASSWORD, name, Role.USER)
            user_service.apply_profile(user, profile, db)

            plan = Plan(
                user_id=user.id,
                version=1,
                kind=PlanKind.ORIGINAL,
                content=_sample_plan(profile).model_dump(),
                profile_snapshot={
                    "display_name": name,
                    "age": profile.age,
                    "weight_kg": profile.weight_kg,
                    "goal": profile.goal.value,
                    "intensity": profile.intensity.value,
                    "notes": profile.notes or "",
                },
                tip=_tip_for(profile.goal),
                model_name="seed-data (no AI call)",
                prompt_version=PROMPT_VERSION,
            )
            db.add(plan)
            db.commit()
            db.refresh(plan)

            # A revision, built from the original so the chain is real.
            for position, feedback in enumerate(feedback_list, start=1):
                revised = _sample_plan(profile)
                db.add(
                    Plan(
                        user_id=user.id,
                        version=position + 1,
                        parent_plan_id=plan.id,
                        kind=PlanKind.REVISION,
                        feedback_text=feedback,
                        content=revised.model_dump(),
                        profile_snapshot=plan.profile_snapshot,
                        tip=_tip_for(profile.goal),
                        model_name="seed-data (no AI call)",
                        prompt_version=PROMPT_VERSION,
                    )
                )
                db.commit()
                print(f"  revision v{position + 1} for {name}: '{feedback}'")

        print()
        print("Demo data ready:")
        print(f"  admin    {coach.email}  (role=admin)")
        for email, *_rest in members:
            print(f"  member   {email}  (role=user)")
        print(f"\nAll demo passwords: {DEMO_PASSWORD}")
        print(f"Admin credentials: {args.admin_email} / {DEMO_PASSWORD}")
        if not settings.ai_available:
            print("\nNote: GEMINI_API_KEY is not set, so real generation will fail.")
    finally:
        db.close()
    return 0


def cmd_reset_db(args: argparse.Namespace) -> int:
    """Drop and recreate every table. Local development only."""
    engine = get_engine()
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    print("Database reset.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="app.cli", description="FitBuddy admin commands")
    sub = parser.add_subparsers(dest="command", required=True)

    admin = sub.add_parser("create-admin", help="Create an admin account")
    admin.add_argument("--email", required=True)
    admin.add_argument("--password", required=True)
    admin.add_argument("--name", default="Coach", help="Display name")
    admin.set_defaults(func=cmd_create_admin)

    seed = sub.add_parser("seed-demo", help="Create demo users and plan history")
    seed.add_argument("--admin-email", default="coach@demo.dev")
    seed.set_defaults(func=cmd_seed_demo)

    listing = sub.add_parser("list-users", help="List all users")
    listing.set_defaults(func=cmd_list_users)

    reset = sub.add_parser("reset-db", help="Drop and recreate all tables")
    reset.set_defaults(func=cmd_reset_db)

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except ConflictError as exc:
        print(f"error: {exc.message}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
