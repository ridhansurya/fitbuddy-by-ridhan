"""Pydantic v2 schemas: user inputs, API payloads, and the AI output contract.

One schema set is reused for form parsing, API validation *and* validating the
model's JSON, so there is a single definition of "a valid plan" (spec section 8.2).
"""

from __future__ import annotations

import datetime as dt
from typing import Annotated, Any, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    EmailStr,
    Field,
    StringConstraints,
    field_validator,
    model_validator,
)

from app.enums import Goal, Intensity, PlanKind, Role

# ---------------------------------------------------------------------------
# Shared constrained string types
# ---------------------------------------------------------------------------

NonEmptyText = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]
DisplayName = Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=60)]
#: Short, optional. Bounded to keep untrusted text out of the prompt (spec S3).
Notes = Annotated[str, StringConstraints(strip_whitespace=True, max_length=200)]
Feedback = Annotated[str, StringConstraints(strip_whitespace=True, min_length=3, max_length=500)]
Password = Annotated[str, StringConstraints(min_length=8, max_length=128)]


# ---------------------------------------------------------------------------
# User-facing inputs
# ---------------------------------------------------------------------------


class ProfileInput(BaseModel):
    """The fitness profile a plan is generated from."""

    model_config = ConfigDict(extra="forbid")

    display_name: DisplayName
    age: int = Field(ge=16, le=90, description="Age in years (16-90)")
    weight_kg: float = Field(ge=30.0, le=250.0, description="Body weight in kilograms")
    goal: Goal
    intensity: Intensity
    notes: Notes | None = None

    @field_validator("weight_kg")
    @classmethod
    def _round_weight(cls, value: float) -> float:
        return round(value, 1)


class RegisterInput(BaseModel):
    """New account. ``extra='forbid'`` means a posted ``role`` field is rejected."""

    model_config = ConfigDict(extra="forbid")

    display_name: DisplayName
    email: EmailStr
    password: Password

    @field_validator("password")
    @classmethod
    def _password_rules(cls, value: str) -> str:
        if not any(c.isalpha() for c in value) or not any(c.isdigit() for c in value):
            raise ValueError("Password must contain at least one letter and one number")
        return value

    @field_validator("email")
    @classmethod
    def _normalise_email(cls, value: str) -> str:
        return value.strip().lower()


class LoginInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    email: EmailStr
    password: Annotated[str, StringConstraints(min_length=1, max_length=128)]

    @field_validator("email")
    @classmethod
    def _normalise_email(cls, value: str) -> str:
        return value.strip().lower()


class FeedbackInput(BaseModel):
    """A user's request to change an existing plan."""

    model_config = ConfigDict(extra="forbid")

    feedback: Feedback


# ---------------------------------------------------------------------------
# AI output contract - the structured plan
# ---------------------------------------------------------------------------


class Warmup(BaseModel):
    model_config = ConfigDict(extra="forbid")

    duration_min: int = Field(ge=3, le=20)
    items: list[NonEmptyText] = Field(min_length=1, max_length=8)

    @field_validator("items")
    @classmethod
    def _cap_item_length(cls, value: list[str]) -> list[str]:
        return [item[:80] for item in value]


class Exercise(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=80)]
    sets: int = Field(ge=1, le=10)
    #: Free-form because "30 sec" and "10-12" are both legitimate.
    reps: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=24)]
    rest_sec: int = Field(ge=15, le=300)

    @field_validator("reps")
    @classmethod
    def _normalise_reps(cls, value: str) -> str:
        # Models like to emit en/em dashes; normalise so the UI renders one style.
        dashes = {chr(0x2013): "-", chr(0x2014): "-", "~": "-"}
        return value.translate(str.maketrans(dashes)).strip()


class PlanDay(BaseModel):
    model_config = ConfigDict(extra="forbid")

    day: int = Field(ge=1, le=7)
    focus: Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=80)]
    is_rest_day: bool
    warmup: Warmup
    exercises: list[Exercise] = Field(default_factory=list, max_length=8)
    cooldown: Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=200)]

    @model_validator(mode="after")
    def _rest_day_shape(self) -> PlanDay:
        """A rest day must not prescribe exercises, and vice versa."""
        if self.is_rest_day and self.exercises:
            raise ValueError(f"Day {self.day} is flagged as a rest day but lists exercises")
        if not self.is_rest_day and not self.exercises:
            raise ValueError(f"Day {self.day} is a training day but has no exercises")
        return self

    @property
    def total_sets(self) -> int:
        return sum(exercise.sets for exercise in self.exercises)

    @property
    def estimated_minutes(self) -> int:
        """Rough session length, used for display only."""
        if self.is_rest_day:
            return 0
        working = sum(e.sets * 0.75 for e in self.exercises) + len(self.exercises) * 0.5
        rest = sum(e.rest_sec * e.sets for e in self.exercises) / 60
        return int(self.warmup.duration_min + working + rest + 5)


class WorkoutPlan(BaseModel):
    """A complete 7-day plan. This is what the model must return, and what we store."""

    model_config = ConfigDict(extra="forbid")

    summary: Annotated[str, StringConstraints(strip_whitespace=True, min_length=10, max_length=400)]
    days: list[PlanDay] = Field(min_length=7, max_length=7)
    notes: list[NonEmptyText] = Field(default_factory=list, max_length=6)

    @field_validator("notes")
    @classmethod
    def _cap_note_length(cls, value: list[str]) -> list[str]:
        return [note[:160] for note in value]

    @model_validator(mode="after")
    def _week_is_coherent(self) -> WorkoutPlan:
        """The acceptance criteria and the safety rules in one place.

        Rejecting an incoherent week here means a bad plan can never be saved.
        """
        numbers = [day.day for day in self.days]
        if sorted(numbers) != list(range(1, 8)):
            raise ValueError(f"Plan must cover days 1-7 exactly once, got {sorted(numbers)}")

        if not any(day.is_rest_day for day in self.days):
            # Training every day without a single rest day is the classic
            # overtraining mistake; the system prompt forbids it.
            raise ValueError("Plan must include at least one rest day")

        rest_days = [day.day for day in self.days if day.is_rest_day]
        if len(rest_days) > 4:
            raise ValueError("Plan has more than 4 rest days, which is not a training week")

        return self

    @property
    def training_days(self) -> list[PlanDay]:
        return [day for day in self.days if not day.is_rest_day]

    @property
    def rest_day_count(self) -> int:
        return sum(1 for day in self.days if day.is_rest_day)


# ---------------------------------------------------------------------------
# API responses
# ---------------------------------------------------------------------------


class ErrorBody(BaseModel):
    code: str
    message: str
    field: str | None = None
    request_id: str | None = None


class ErrorResponse(BaseModel):
    """The single error envelope used by every endpoint (spec section 11.3)."""

    error: ErrorBody


class UserOut(BaseModel):
    id: int
    email: EmailStr
    display_name: str
    role: Role
    age: int | None
    weight_kg: float | None
    goal: Goal | None
    intensity: Intensity | None
    created_at: dt.datetime

    @classmethod
    def from_model(cls, user: Any) -> UserOut:
        return cls(
            id=user.id,
            email=user.email,
            display_name=user.display_name,
            role=user.role,
            age=user.age,
            weight_kg=user.weight_kg,
            goal=user.goal,
            intensity=user.intensity,
            created_at=user.created_at,
        )


class PlanOut(BaseModel):
    id: int
    user_id: int
    version: int
    kind: PlanKind
    parent_plan_id: int | None
    feedback_text: str | None
    content: WorkoutPlan
    tip: str
    model_name: str
    prompt_version: str
    created_at: dt.datetime

    @classmethod
    def from_model(cls, plan: Any) -> PlanOut:
        return cls(
            id=plan.id,
            user_id=plan.user_id,
            version=plan.version,
            kind=plan.kind,
            parent_plan_id=plan.parent_plan_id,
            feedback_text=plan.feedback_text,
            content=WorkoutPlan.model_validate(plan.content),
            tip=plan.tip,
            model_name=plan.model_name,
            prompt_version=plan.prompt_version,
            created_at=plan.created_at,
        )


class PlanCreatedOut(PlanOut):
    """A newly created plan, plus the identity of who owns it."""

    owner_display_name: str


class TipOut(BaseModel):
    goal: Goal
    tip: str
    word_count: int
    cached: bool = False


class AdminUserRow(BaseModel):
    """One row on the coach dashboard."""

    user: UserOut
    plan_count: int
    latest_plan: PlanOut | None = None
    latest_version: int | None = None


class AdminUserListOut(BaseModel):
    items: list[AdminUserRow]
    total: int
    page: int
    page_size: int
    pages: int


class HealthOut(BaseModel):
    status: Literal["ok", "degraded"]
    database: Literal["ok", "unavailable"]
    version: str
    ai_configured: bool
    model_plan: str
    model_tip: str


# ---------------------------------------------------------------------------
# JSON Schema for the model's structured output
# ---------------------------------------------------------------------------


def inline_refs(schema: dict[str, Any]) -> dict[str, Any]:
    """Inline ``$ref`` pointers and drop ``$defs`` from a JSON Schema.

    Gemini's structured-output mode is more reliable on a flat schema. Doing
    this by hand-written duplication would let the schema and the Pydantic
    model drift apart, so it is derived from the model instead.
    """
    defs = schema.get("$defs", {})

    def resolve(node: Any) -> Any:
        if isinstance(node, dict):
            ref = node.get("$ref")
            if isinstance(ref, str) and ref.startswith("#/$defs/"):
                target = defs[ref.split("/")[-1]]
                # Merge sibling keys (rare, but JSON Schema allows them).
                return {
                    **resolve(target),
                    **{k: resolve(v) for k, v in node.items() if k != "$ref"},
                }
            return {k: resolve(v) for k, v in node.items() if k != "$defs"}
        if isinstance(node, list):
            return [resolve(item) for item in node]
        return node

    resolved = resolve(dict(schema))
    resolved.pop("$defs", None)
    return resolved


def plan_json_schema() -> dict[str, Any]:
    """Flat JSON Schema handed to Gemini for structured output."""
    return inline_refs(WorkoutPlan.model_json_schema())
