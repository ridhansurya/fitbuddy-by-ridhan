# Drop your own photo here as gym-bg.jpg to replace the gradient backdrop.
#
# The app renders correctly without it: app.css falls back to gradients, and all
# text sits on an opaque panel, so contrast is never affected either way.
#
# Suggested: a dark, low-contrast gym photo, 1920x1080 or larger, under ~300 KB.
# Do not commit images you do not have the licence to redistribute.
