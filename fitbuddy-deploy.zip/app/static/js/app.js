/* FitBuddy - progressive enhancement only. Every feature works with JS off;
   this just adds a loading state for the slow AI call and a delete confirmation.
*/
(function () {
  "use strict";

  /* ---------- loading state for form submissions ---------- */

  function showBusy(form) {
    var message = form.getAttribute("data-busy-message") || "Working...";
    var button = form.querySelector("[data-busy-button]");

    if (button) {
      button.setAttribute("aria-busy", "true");
      button.disabled = true;
      var label = button.textContent;
      button.textContent = message;
      button.setAttribute("data-original-label", label);
    }

    var overlay = document.createElement("div");
    overlay.className = "busy-overlay";
    overlay.setAttribute("role", "status");
    overlay.setAttribute("aria-live", "polite");

    var box = document.createElement("div");
    box.className = "busy-box";

    var spinner = document.createElement("div");
    spinner.className = "spinner";

    var text = document.createElement("p");
    text.textContent = message;

    box.appendChild(spinner);
    box.appendChild(text);
    overlay.appendChild(box);
    document.body.appendChild(overlay);
  }

  document.addEventListener(
    "submit",
    function (event) {
      var form = event.target;
      if (!(form instanceof HTMLFormElement)) return;
      // Only forms that hit the AI need a spinner; plain forms are instant.
      if (!form.hasAttribute("data-busy-message")) return;
      // Let the browser run its own validation first.
      if (typeof form.reportValidity === "function" && !form.reportValidity()) return;
      showBusy(form);
    },
    true
  );

  /* ---------- confirm destructive admin actions ---------- */

  document.addEventListener(
    "submit",
    function (event) {
      var form = event.target;
      if (!(form instanceof HTMLFormElement)) return;
      var message = form.getAttribute("data-confirm");
      if (message && !window.confirm(message)) {
        event.preventDefault();
        event.stopPropagation();
      }
    },
    true
  );
})();
