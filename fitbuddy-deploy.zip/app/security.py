"""Authentication, authorisation and CSRF.

Design decisions worth knowing:

* **Sessions are signed HttpOnly cookies** handled by Starlette's
  ``SessionMiddleware``. The cookie is signed but not encrypted, so it must only
  ever contain a user id - never a role, never profile data, and never
  anything derived from a form.
* **The user id always comes from the session.** No route accepts a user id
  from a form or request body. That was the IDOR in the original proof of
  concept (spec finding S2).
* **Ownership failures return 404, not 403**, so the app does not confirm that
  someone else's plan exists.
"""

from __future__ import annotations

import contextlib
import hmac
import logging
import secrets
from typing import Annotated

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError
from fastapi import Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_db
from app.enums import Role
from app.errors import AuthenticationError, NotFoundError, PermissionDeniedError
from app.models import Plan, User

logger = logging.getLogger(__name__)

#: Session key holding the authenticated user's primary key.
SESSION_USER_ID = "user_id"
#: Session key holding the CSRF secret. Rotated whenever the user logs in.
SESSION_CSRF = "csrf_token"

#: Only these request methods can change state, so only these need CSRF tokens.
UNSAFE_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})

#: Sentinel distinguishing "not resolved yet" from a resolved ``None``.
_MISSING = object()

# OWASP-recommended argon2id parameters. Replaced with cheap parameters by the
# test suite via use_fast_hashing(), so hundreds of tests do not take minutes.
_hasher = PasswordHasher()


def use_fast_hashing() -> None:
    """Drop the argon2 cost parameters to the minimum. Test-only."""
    global _hasher, _DUMMY_HASH
    _hasher = PasswordHasher(time_cost=1, memory_cost=8, parallelism=1)
    # Regenerate the timing-equaliser hash so it uses the same cheap parameters.
    _DUMMY_HASH = _hasher.hash("fitbuddy-timing-equaliser-" + secrets.token_urlsafe(16))


# ---------------------------------------------------------------------------
# Passwords
# ---------------------------------------------------------------------------


def hash_password(password: str) -> str:
    """Hash a plaintext password with argon2id."""
    return _hasher.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    """Check a password against a stored hash, in constant time.

    Returns ``False`` rather than raising on a malformed hash, and verifies
    against a dummy hash when the account is unknown so that a missing account
    and a wrong password take the same time to answer.
    """
    if not password_hash:
        _verify_dummy(password)
        return False
    try:
        _hasher.verify(password_hash, password)
    except (VerificationError, InvalidHashError):
        return False
    return True


#: A precomputed hash of an unguessable value, used only to equalise timing.
_DUMMY_HASH = _hasher.hash("fitbuddy-timing-equaliser-" + secrets.token_urlsafe(16))


def _verify_dummy(password: str) -> None:
    with contextlib.suppress(VerificationError, InvalidHashError):
        _hasher.verify(_DUMMY_HASH, password)


def needs_rehash(password_hash: str) -> bool:
    """True when a stored hash uses outdated parameters and should be upgraded."""
    try:
        return _hasher.check_needs_rehash(password_hash)
    except InvalidHashError:
        return False


# ---------------------------------------------------------------------------
# CSRF
# ---------------------------------------------------------------------------


def get_csrf_token(request: Request) -> str:
    """Return this session's CSRF token, creating one if needed.

    The token is stored in the signed session cookie, so it cannot be forged
    without ``SECRET_KEY``.
    """
    token = request.session.get(SESSION_CSRF)
    if not isinstance(token, str) or not token:
        token = secrets.token_urlsafe(32)
        request.session[SESSION_CSRF] = token
    return token


async def require_csrf(request: Request) -> None:
    """Dependency that rejects state-changing requests without a valid token.

    Applied to HTML form routes. The ``/api/v1`` surface is CSRF-exempt by
    design (it is the programmatic API used by tests and Swagger); it relies on
    ``SameSite=Lax`` cookies, which already block cross-site form posts. See
    the README "Known gaps" section.
    """
    if request.method.upper() not in UNSAFE_METHODS:
        return

    expected = request.session.get(SESSION_CSRF)
    if not isinstance(expected, str) or not expected:
        raise PermissionDeniedError("Your session expired. Please reload the page and try again.")

    supplied = request.headers.get("X-CSRF-Token")
    if not supplied:
        form = await request.form()
        supplied = form.get("csrf_token")
        if not isinstance(supplied, str):
            supplied = None

    if not supplied or not hmac.compare_digest(supplied, expected):
        logger.warning("csrf_rejected path=%s", request.url.path)
        raise PermissionDeniedError("Your form session expired. Please reload and try again.")


async def csrf_token_dependency(request: Request) -> str:
    """Alias kept for readability at call sites."""
    return get_csrf_token(request)


# ---------------------------------------------------------------------------
# Session lifecycle
# ---------------------------------------------------------------------------


def login_session(request: Request, user: User) -> None:
    """Start a session for ``user``, rotating the CSRF token.

    Rotating on login prevents session fixation: a token an attacker planted
    before login cannot be used against the new authenticated session.
    """
    request.session.clear()
    request.session[SESSION_USER_ID] = user.id
    request.session[SESSION_CSRF] = secrets.token_urlsafe(32)


def logout_session(request: Request) -> None:
    request.session.clear()


# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------


def get_optional_user(
    request: Request,
    db: Annotated[Session, Depends(get_db)],
) -> User | None:
    """The signed-in user, or ``None`` for a visitor. Never raises.

    The result is cached on ``request.state`` so templates can read the current
    user without every route having to pass it through explicitly.
    """
    cached = getattr(request.state, "user", _MISSING)
    if cached is not _MISSING:
        return cached

    user_id = request.session.get(SESSION_USER_ID)
    user: User | None = None
    if isinstance(user_id, int):
        user = db.get(User, user_id)
        if user is None:
            # The account was deleted while the cookie was still valid.
            request.session.clear()

    request.state.user = user
    return user


def get_current_user(user: Annotated[User | None, Depends(get_optional_user)]) -> User:
    """Require an authenticated user. Raises 401 otherwise."""
    if user is None:
        raise AuthenticationError("Please log in to continue.")
    return user


def require_admin(user: Annotated[User, Depends(get_current_user)]) -> User:
    """Require the coach/admin role. Raises 401 then 403."""
    if user.role != Role.ADMIN:
        raise PermissionDeniedError("This area is restricted to coaches.")
    return user


CurrentUser = Annotated[User, Depends(get_current_user)]
AdminUser = Annotated[User, Depends(require_admin)]
OptionalUser = Annotated[User | None, Depends(get_optional_user)]
DbSession = Annotated[Session, Depends(get_db)]


# ---------------------------------------------------------------------------
# Object-level authorisation
# ---------------------------------------------------------------------------


def get_plan_or_404(
    plan_id: int,
    db: Session,
    viewer: User,
    *,
    allow_admin: bool = True,
) -> Plan:
    """Load a plan the viewer is allowed to read.

    Admins may read any plan (that is the coach oversight job). Everyone else
    may only read their own. A plan belonging to someone else is reported as
    404 rather than 403, so the app never confirms that it exists.
    """
    plan = db.get(Plan, plan_id)
    if plan is None:
        raise NotFoundError("That plan does not exist.")
    if plan.user_id == viewer.id:
        return plan
    if allow_admin and viewer.is_admin:
        return plan
    raise NotFoundError("That plan does not exist.")


def require_plan_owner(plan: Plan, viewer: User) -> None:
    """Guard writes. Revisions are owner-only, even for admins.

    A coach can *see* a plan but must not be able to rewrite someone's training
    programme (spec section 3: "cannot edit plan content").
    """
    if plan.user_id != viewer.id:
        raise NotFoundError("That plan does not exist.")


def owns_resource(user_id: int, viewer: User) -> bool:
    """Ownership predicate, kept in one place so it is easy to audit."""
    return user_id == viewer.id or viewer.is_admin


def find_user_by_email(db: Session, email: str) -> User | None:
    """Case-insensitive account lookup."""
    normalised = email.strip().lower()
    return db.scalar(select(User).where(User.email == normalised))
