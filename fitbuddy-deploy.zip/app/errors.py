"""Application errors and the single JSON envelope every endpoint returns on failure.

Two rules this module enforces:

1. A stack trace or provider message never reaches the client. The detail is
   logged with a request id; the client gets a friendly message it can act on.
2. A failed AI call raises - it is never converted into plan content and stored
   (spec finding S4).
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

logger = logging.getLogger(__name__)


class AppError(Exception):
    """Base class for expected, user-facing failures.

    :param message: shown to the user. Must be safe to display.
    :param field:   the offending form field, when the failure is a validation one.
    """

    status_code: int = 400  # Bad Request
    code: str = "BAD_REQUEST"

    def __init__(self, message: str, *, field: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.field = field

    def to_payload(self, request_id: str | None) -> dict[str, Any]:
        return {
            "error": {
                "code": self.code,
                "message": self.message,
                "field": self.field,
                "request_id": request_id,
            }
        }


class ValidationError(AppError):
    status_code = 422
    code = "VALIDATION_ERROR"


class AuthenticationError(AppError):
    status_code = 401
    code = "UNAUTHENTICATED"


class PermissionDeniedError(AppError):
    status_code = 403
    code = "FORBIDDEN"


class NotFoundError(AppError):
    status_code = 404
    code = "NOT_FOUND"

    def __init__(self, message: str = "The requested item was not found.") -> None:
        super().__init__(message)


class ConflictError(AppError):
    status_code = 409
    code = "CONFLICT"


class RateLimitError(AppError):
    status_code = 429
    code = "RATE_LIMITED"

    def __init__(self, message: str, *, retry_after_sec: int = 60) -> None:
        super().__init__(message)
        self.retry_after_sec = retry_after_sec

    def to_payload(self, request_id: str | None) -> dict[str, Any]:
        payload = super().to_payload(request_id)
        payload["error"]["retry_after_sec"] = self.retry_after_sec
        return payload


class AIServiceError(AppError):
    """The AI provider failed or is not configured.

    Surfaced as 502: the request was valid, the upstream dependency was not.
    """

    status_code = 502
    code = "AI_UNAVAILABLE"

    def __init__(
        self, message: str = "We couldn't reach the plan generator. Please try again."
    ) -> None:
        super().__init__(message)


class AIResponseError(AppError):
    """The model replied, but not with something we can store.

    Shown to the user as a friendly failure; never persisted as a plan.
    """

    status_code = 502
    code = "AI_INVALID_RESPONSE"

    def __init__(
        self, message: str = "The generator returned something unusable. Please try again."
    ) -> None:
        super().__init__(message)


def request_id_of(request: Request) -> str | None:
    return getattr(request.state, "request_id", None)


def _error_response(
    request: Request, exc: AppError, *, headers: dict[str, str] | None = None
) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status_code,
        content=exc.to_payload(request_id_of(request)),
        headers=headers,
    )


def _field_of(error: dict[str, Any]) -> tuple[str | None, str]:
    """Pick the most useful field name and message from a Pydantic error."""
    loc = [part for part in error.get("loc", ()) if part not in ("body", "query", "path")]
    field = str(loc[-1]) if loc else None
    return field, str(error.get("msg", "Invalid value"))


def register_exception_handlers(app: FastAPI, *, html: bool = True) -> None:
    """Install handlers so every failure - ours, FastAPI's, or unhandled - uses one shape.

    :param html: when true, browser requests get a rendered error page and API
        clients get the JSON envelope. Content negotiation is by path prefix.
    """
    from fastapi.templating import Jinja2Templates  # local import avoids a cycle

    templates: Jinja2Templates | None = getattr(app.state, "templates", None)

    def wants_html(request: Request) -> bool:
        if not html or templates is None:
            return False
        return not request.url.path.startswith(("/api/", "/healthz"))

    async def render_or_json(
        request: Request, exc: AppError, status_code: int, headers: dict[str, str] | None = None
    ) -> JSONResponse:
        if wants_html(request):
            return templates.TemplateResponse(
                request=request,
                name="error.html",
                context={
                    "status_code": status_code,
                    "code": exc.code,
                    "message": exc.message,
                    "request_id": request_id_of(request),
                },
                status_code=status_code,
                headers=headers,
            )
        return JSONResponse(
            status_code=status_code,
            content=exc.to_payload(request_id_of(request)),
            headers=headers,
        )

    @app.exception_handler(AppError)
    async def _app_error(request: Request, exc: AppError) -> JSONResponse:
        headers = None
        if isinstance(exc, RateLimitError):
            headers = {"Retry-After": str(exc.retry_after_sec)}
        return await render_or_json(request, exc, exc.status_code, headers)

    @app.exception_handler(RequestValidationError)
    async def _validation_error(request: Request, exc: RequestValidationError) -> JSONResponse:
        errors = exc.errors()
        field, message = _field_of(errors[0]) if errors else (None, "Invalid request")
        # Pydantic messages look like "Value error, Password must contain...".
        clean = message.removeprefix("Value error, ").capitalize()
        return await render_or_json(request, ValidationError(clean, field=field), 422)

    @app.exception_handler(StarletteHTTPException)
    async def _http_error(request: Request, exc: StarletteHTTPException) -> JSONResponse:
        code = {
            401: "UNAUTHENTICATED",
            403: "FORBIDDEN",
            404: "NOT_FOUND",
            405: "METHOD_NOT_ALLOWED",
        }.get(exc.status_code, "HTTP_ERROR")
        mapped = AppError(str(exc.detail or "Request failed"))
        mapped.status_code = exc.status_code
        mapped.code = code
        return await render_or_json(
            request, mapped, exc.status_code, headers=dict(exc.headers or {})
        )

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception) -> JSONResponse:
        # Log the detail, return a generic message: never leak internals (S6).
        logger.exception(
            "unhandled_error path=%s request_id=%s", request.url.path, request_id_of(request)
        )
        return await render_or_json(
            request,
            AppError("Something went wrong on our side. Please try again."),
            500,
        )
