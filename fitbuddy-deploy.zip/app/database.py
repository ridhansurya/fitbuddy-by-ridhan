"""Database engine, session factory and the FastAPI session dependency."""

from __future__ import annotations

from collections.abc import Generator
from typing import Any

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import get_settings

_engine: Engine | None = None
_SessionLocal: sessionmaker[Session] | None = None


class Base(DeclarativeBase):
    """Declarative base for all ORM models."""


def _engine_kwargs(url: str) -> dict[str, Any]:
    """Engine options appropriate for the configured database."""
    if url.startswith("sqlite"):
        # FastAPI serves requests from a threadpool, so a connection may be
        # touched by a different thread than the one that opened it.
        return {"connect_args": {"check_same_thread": False}}
    return {"pool_pre_ping": True}


@event.listens_for(Engine, "connect")
def _sqlite_pragmas(dbapi_connection: Any, _record: Any) -> None:
    """Turn on SQLite foreign-key enforcement for every new connection.

    SQLite ships with ``foreign_keys`` OFF, and the pragma is per-connection.
    Without this, ``ON DELETE CASCADE`` is silently ignored: the ORM
    relationships use ``passive_deletes=True`` (so it does not cascade in
    Python either) and deleting a user would leave their plans behind as
    orphans. This is the only place the setting can be applied, because the
    engine hands out connections from a pool.
    """
    module = type(dbapi_connection).__module__
    if not module.startswith("sqlite3") and not module.startswith("pysqlite"):
        return
    cursor = dbapi_connection.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys=ON")
    finally:
        cursor.close()


def get_engine() -> Engine:
    """Lazily create the process-wide engine."""
    global _engine
    if _engine is None:
        settings = get_settings()
        url = settings.sqlalchemy_url
        _engine = create_engine(url, **_engine_kwargs(url))
    return _engine


def get_sessionmaker() -> sessionmaker[Session]:
    """Lazily create the process-wide session factory."""
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(
            bind=get_engine(),
            autoflush=False,
            autocommit=False,
            expire_on_commit=False,
        )
    return _SessionLocal


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency yielding a request-scoped session.

    The session is always closed, even when the handler raises, which prevents
    connection leaks on error paths.
    """
    session = get_sessionmaker()()
    try:
        yield session
    finally:
        session.close()


def reset_engine() -> None:
    """Dispose the engine and session factory.

    Used by the test suite so each run can point at a fresh database.
    """
    global _engine, _SessionLocal
    if _engine is not None:
        _engine.dispose()
    _engine = None
    _SessionLocal = None
