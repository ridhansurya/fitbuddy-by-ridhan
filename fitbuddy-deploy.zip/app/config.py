"""Application settings, loaded from the environment (and a local .env file).

Every deployment-specific value lives here so that no secret or environment
detail is hard-coded anywhere else in the codebase.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

#: Rejected in any non-local environment so a sample key can never reach production.
INSECURE_SECRET_KEYS = {
    "change-me-to-a-long-random-string",
    "changeme",
    "secret",
    "dev",
    "",
}


class Settings(BaseSettings):
    """Runtime configuration. Instantiate through :func:`get_settings`."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # --- security ---------------------------------------------------------
    secret_key: str = Field(
        default="change-me-to-a-long-random-string",
        description="Signing key for session cookies. Generate a long random value.",
    )
    app_env: Literal["local", "test", "production"] = "local"

    # --- database ---------------------------------------------------------
    database_url: str = "sqlite:///./fitbuddy.db"

    # --- AI provider ------------------------------------------------------
    ai_provider: Literal["gemini", "openai"] = "gemini"
    gemini_api_key: str = Field(
        default="",
        description="Google Gemini API key. Empty disables live AI calls.",
    )
    gemini_model_plan: str = "gemini-3.6-flash"
    gemini_model_tip: str = "gemini-3.6-flash"
    gemini_model_fallbacks: str = "gemini-3-flash-preview,gemini-3.5-flash"
    openai_api_key: str = Field(
        default="",
        description="OpenAI-compatible key (any provider: OpenAI, Groq, OpenRouter).",
    )
    openai_base_url: str = "https://api.openai.com/v1"
    openai_model_plan: str = "gpt-4o-mini"
    openai_model_tip: str = "gpt-4o-mini"
    openai_model_fallbacks: str = "gpt-4o"
    gemini_timeout_sec: float = Field(default=45.0, ge=5.0, le=300.0)

    # --- sessions & limits ------------------------------------------------
    session_max_age_sec: int = Field(default=604_800, ge=300, le=2_592_000)
    daily_generation_quota: int = Field(default=10, ge=1, le=1_000)
    rate_limit_per_min: int = Field(default=6, ge=1, le=120)

    # --- derived ----------------------------------------------------------
    @property
    def is_testing(self) -> bool:
        return self.app_env == "test"

    @property
    def ai_available(self) -> bool:
        """Whether live AI calls can be attempted for the active provider."""
        key = self.openai_api_key if self.ai_provider == "openai" else self.gemini_api_key
        return bool(key.strip())

    @property
    def _provider_models(self) -> str:
        """Primary plus fallback models for the active provider, comma-joined."""
        if self.ai_provider == "openai":
            return self.openai_model_plan + "," + self.openai_model_fallbacks
        return self.gemini_model_plan + "," + self.gemini_model_fallbacks

    @property
    def plan_model_candidates(self) -> list[str]:
        """Primary model plus fallbacks, in order of preference.

        Providers throttle models independently by demand and quota, so
        generation tries each candidate until one responds.
        """
        return [m.strip() for m in self._provider_models.split(",") if m.strip()]

    @property
    def cookies_secure(self) -> bool:
        """Only require HTTPS cookies in production, so local http dev still works."""
        return self.app_env == "production"

    @field_validator("database_url")
    @classmethod
    def _strip_database_url(cls, value: str) -> str:
        return value.strip()

    @model_validator(mode="after")
    def _reject_insecure_production_secrets(self) -> Settings:
        if self.app_env == "production":
            if self.secret_key.strip().lower() in INSECURE_SECRET_KEYS:
                raise ValueError(
                    "SECRET_KEY must be set to a long random value when APP_ENV=production"
                )
            if not self.ai_available:
                raise ValueError(
                    "an AI API key is required when APP_ENV=production "
                    "(GEMINI_API_KEY or OPENAI_API_KEY for the active provider)"
                )
        return self

    @property
    def sqlalchemy_url(self) -> str:
        """Normalised database URL for SQLAlchemy.

        SQLAlchemy needs an absolute path for SQLite files, otherwise the file
        location depends on the process working directory.
        """
        prefix = "sqlite:///"
        if not self.database_url.startswith(prefix):
            return self.database_url

        raw_path = self.database_url[len(prefix) :]
        if not raw_path or raw_path == ":memory:":
            return self.database_url

        from pathlib import Path

        return f"{prefix}{Path(raw_path).expanduser().resolve()}"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the process-wide settings singleton."""
    return Settings()
