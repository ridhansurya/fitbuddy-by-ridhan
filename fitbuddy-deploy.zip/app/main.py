"""Application factory, middleware and lifespan.

Run with::

    uvicorn app.main:app --reload
"""

from __future__ import annotations

import logging
import time
import uuid
from pathlib import Path
from typing import Any

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.datastructures import Headers, MutableHeaders
from starlette.middleware.sessions import SessionMiddleware
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from app.config import get_settings
from app.database import get_engine
from app.errors import register_exception_handlers
from app.templating import build_templates
from app.version import __version__

logger = logging.getLogger("fitbuddy")

STATIC_DIR = Path(__file__).parent / "static"

#: Requests slower than this are logged at WARNING so slow AI calls are visible.
SLOW_REQUEST_SEC = 2.0

#: Conservative CSP. The page uses no inline script and no third-party origins.
#: 'unsafe-inline' is limited to styles because Jinja templates need it for the
#: small amount of dynamic styling; script-src stays strict.
CONTENT_SECURITY_POLICY = (
    "default-src 'self'; "
    "script-src 'self'; "
    "style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data:; "
    "font-src 'self'; "
    "connect-src 'self'; "
    "form-action 'self'; "
    "frame-ancestors 'none'; "
    "base-uri 'self'"
)

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=()",
}


def configure_logging(level: str) -> None:
    """Structured-ish logging. Deliberately never logs PII or prompt contents."""
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)-7s %(name)s %(message)s",
    )
    # These libraries are chatty at INFO and add nothing we act on.
    for noisy in ("httpx", "httpcore", "urllib3", "google_genai"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def create_app() -> FastAPI:
    """Build and configure the application."""
    settings = get_settings()
    configure_logging("INFO" if not settings.is_testing else "WARNING")

    app = FastAPI(
        title="FitBuddy",
        version=__version__,
        description=(
            "Personalized 7-day workout plans. Every AI call is a single bounded "
            "request/response - this is not an agentic system."
        ),
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    # Session cookies must be signed. http_only blocks script access,
    # same_site blocks cross-site cookie sending, secure is required in production.
    app.add_middleware(
        SessionMiddleware,
        secret_key=settings.secret_key,
        session_cookie="fitbuddy_session",
        max_age=settings.session_max_age_sec,
        same_site="lax",
        https_only=settings.cookies_secure,
    )
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RequestContextMiddleware)

    app.state.settings = settings
    app.state.templates = build_templates()

    from app.routes import admin, api, auth, web

    app.include_router(auth.router)
    app.include_router(web.router)
    app.include_router(admin.router)
    app.include_router(api.router)

    if STATIC_DIR.is_dir():
        app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    register_exception_handlers(app)

    @app.get("/healthz", tags=["system"], summary="Liveness and dependency check")
    def healthz() -> dict[str, Any]:
        """Report service health. The database is checked; the AI provider is not,
        so a slow or rate-limited provider cannot fail the probe."""
        database_ok = True
        try:
            with get_engine().connect() as connection:
                connection.exec_driver_sql("SELECT 1")
        # Any driver-level failure means the database is unavailable.
        except Exception:
            logger.warning("healthz database check failed", exc_info=True)
            database_ok = False

        from fastapi.responses import JSONResponse

        body = {
            "status": "ok" if database_ok else "degraded",
            "database": "ok" if database_ok else "unavailable",
            "version": __version__,
            "ai_configured": settings.ai_available,
            "model_plan": settings.plan_model_candidates[0],
            "model_tip": settings.openai_model_tip
            if settings.ai_provider == "openai"
            else settings.gemini_model_tip,
        }
        if not database_ok:
            return JSONResponse(status_code=503, content=body)
        return body

    logger.info(
        "fitbuddy_started version=%s env=%s ai=%s db=%s",
        __version__,
        settings.app_env,
        "configured" if settings.ai_available else "NOT CONFIGURED",
        settings.database_url.rsplit("/", 1)[-1],
    )
    return app


class SecurityHeadersMiddleware:
    """Attach security headers and a Content-Security-Policy to every response.

    Pure ASGI rather than BaseHTTPMiddleware: it only needs to add headers at
    ``http.response.start``, so it avoids the extra request/response
    reconstruction that BaseHTTPMiddleware performs on every call.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        async def send_with_headers(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers = MutableHeaders(scope=message)
                for name, value in SECURITY_HEADERS.items():
                    headers.setdefault(name, value)
                headers.setdefault("Content-Security-Policy", CONTENT_SECURITY_POLICY)
            await send(message)

        await self.app(scope, receive, send_with_headers)


class RequestContextMiddleware:
    """Assign a request id, record latency, and log the outcome.

    The id is echoed to the client in ``X-Request-ID`` and included in error
    payloads, so a user-reported problem can be traced to a log line without
    exposing any internals. It is stored in ``scope['state']``, which is how
    ``request.state`` is backed, so every downstream ``Request`` can read it.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        scope.setdefault("state", {})
        incoming = Headers(scope=scope).get("x-request-id")
        request_id = incoming or uuid.uuid4().hex[:12]
        scope["state"]["request_id"] = request_id

        started = time.perf_counter()
        status_code: dict[str, int] = {"value": 500}

        async def send_tracked(message: Message) -> None:
            if message["type"] == "http.response.start":
                status_code["value"] = message["status"]
                MutableHeaders(scope=message)["X-Request-ID"] = request_id
            await send(message)

        try:
            await self.app(scope, receive, send_tracked)
        finally:
            duration_ms = (time.perf_counter() - started) * 1000
            level = logging.WARNING if duration_ms > SLOW_REQUEST_SEC * 1000 else logging.INFO
            logger.log(
                level,
                "request path=%s method=%s status=%s duration_ms=%.0f request_id=%s",
                scope.get("path"),
                scope.get("method"),
                status_code["value"],
                duration_ms,
                request_id,
            )


app = create_app()
