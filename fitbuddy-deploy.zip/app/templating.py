"""Shared Jinja2 environment.

Two things are set up here that every template relies on:

* **Autoescape stays on.** No template marks AI-generated text as safe HTML, so
  a model that returns a ``<script>`` tag renders as visible characters.
* **Shared context.** ``current_user``, ``csrf_token`` and the disclaimer are
  injected into every render so no route can forget them.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import Request
from fastapi.templating import Jinja2Templates

from app.enums import GOAL_CHOICES, INTENSITY_CHOICES
from app.security import get_csrf_token

TEMPLATES_DIR = Path(__file__).parent / "templates"

#: Shown before the first generation and on every plan, as the spec requires.
HEALTH_DISCLAIMER = (
    "FitBuddy gives general fitness information, not medical advice. "
    "Talk to a doctor or qualified trainer before starting a new program, "
    "especially if you have an injury or a health condition. Stop any exercise "
    "that causes pain."
)

#: Free-text notice shown on the profile form.
PRIVACY_NOTE = (
    "We store your name, age, weight, goal and plans so your history stays "
    "available to you. Your profile details are sent to Google's Gemini API to "
    "generate a plan."
)


def build_templates() -> Jinja2Templates:
    templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
    templates.env.globals.update(
        goal_choices=GOAL_CHOICES,
        intensity_choices=INTENSITY_CHOICES,
        health_disclaimer=HEALTH_DISCLAIMER,
        privacy_note=PRIVACY_NOTE,
    )
    return templates


def base_context(request: Request) -> dict[str, Any]:
    """Context every page needs.

    ``current_user`` comes from the session, read by the ``get_optional_user``
    dependency which stashes the result on ``request.state``. If a route forgets
    that dependency the value is ``None``, so a template fails closed and shows
    the logged-out view rather than leaking someone else's identity.
    """
    return {
        "request": request,
        "csrf_token": get_csrf_token(request),
        "current_user": getattr(request.state, "user", None),
    }


def render(
    templates: Jinja2Templates,
    request: Request,
    name: str,
    *,
    status_code: int = 200,
    **context: Any,
) -> Any:
    """Render a template with the shared context always merged in.

    Routes call this instead of ``TemplateResponse`` directly so the CSRF token
    and session user cannot be forgotten. ``status_code`` is 422 when
    re-rendering a form after a validation failure, so the status code is honest
    about what happened rather than reporting success.
    """
    return templates.TemplateResponse(
        request=request,
        name=name,
        context={**base_context(request), **context},
        status_code=status_code,
    )
