"""Business logic for plans: generate, revise, retrieve, and the version chain.

The invariant this module exists to protect: **a plan row is only ever written
after the model returned something that passed validation.** AI failures raise,
they do not degrade into stored content (spec finding S4).
"""

from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai import workout
from app.ai.prompts import PROMPT_VERSION
from app.ai.tips import generate_tip
from app.enums import PlanKind
from app.errors import NotFoundError, PermissionDeniedError, ValidationError
from app.models import Plan, User
from app.schemas import FeedbackInput, ProfileInput, WorkoutPlan
from app.services.rate_limit import enforce_generation_limits

logger = logging.getLogger(__name__)

#: Guard against a pathological chain if data is ever corrupted.
MAX_REVISION_DEPTH = 20


def _next_version(db: Session, user_id: int) -> int:
    """The next version number for a user, so the unique constraint always holds."""
    from sqlalchemy import func

    current = db.scalar(select(func.max(Plan.version)).where(Plan.user_id == user_id))
    return (current or 0) + 1


def _snapshot(profile: ProfileInput) -> dict[str, Any]:
    """Record the exact inputs a version was generated from."""
    return {
        "display_name": profile.display_name,
        "age": profile.age,
        "weight_kg": profile.weight_kg,
        "goal": profile.goal.value,
        "intensity": profile.intensity.value,
        "notes": profile.notes or "",
    }


def profile_from_user(user: User) -> ProfileInput:
    """Rebuild a validated profile from a stored user.

    Raises a clear validation error if the user has not completed a profile yet,
    rather than letting a ``None`` reach the prompt layer.
    """
    missing = [
        name
        for name, value in (
            ("age", user.age),
            ("weight_kg", user.weight_kg),
            ("goal", user.goal),
            ("intensity", user.intensity),
        )
        if value is None
    ]
    if missing:
        raise ValidationError("Complete your profile before generating a plan.", field=missing[0])

    return ProfileInput(
        display_name=user.display_name,
        age=user.age,
        weight_kg=user.weight_kg,
        goal=user.goal,
        intensity=user.intensity,
    )


def create_plan(db: Session, user: User, profile: ProfileInput) -> Plan:
    """Generate and store a new original plan.

    Order matters: the quota is checked *before* the AI is called, so a user over
    their limit never burns a paid API call. The tip is best-effort and cannot
    fail the operation.
    """
    enforce_generation_limits(db, user.id)

    plan_content, model_name = workout.generate_plan(profile)
    tip, _ = generate_tip(profile.goal)

    plan = Plan(
        user_id=user.id,
        version=_next_version(db, user.id),
        parent_plan_id=None,
        kind=PlanKind.ORIGINAL,
        feedback_text=None,
        content=plan_content.model_dump(),
        profile_snapshot=_snapshot(profile),
        tip=tip,
        model_name=model_name,
        prompt_version=PROMPT_VERSION,
    )
    db.add(plan)
    db.commit()
    db.refresh(plan)

    logger.info("plan_created plan_id=%s user_id=%s version=%s", plan.id, user.id, plan.version)
    return plan


def create_revision(db: Session, user: User, parent: Plan, feedback: FeedbackInput) -> Plan:
    """Generate and store a revision of ``parent``.

    ``parent`` is never modified. If generation fails, no row is written and the
    original stays exactly as it was.

    Ownership is re-checked here rather than trusted from the caller. The route
    already enforces it, but this is the single entry point for the operation
    (the CLI and the API reach it too), and an IDOR guard that only exists in a
    route is one refactor away from being gone.
    """
    if parent.user_id != user.id:
        raise PermissionDeniedError("That plan belongs to someone else.")

    profile = profile_from_user(user)

    # Re-validate the stored plan before feeding it back to the model.
    previous = WorkoutPlan.model_validate(parent.content)

    plan_content, model_name = workout.revise_plan(
        profile, previous.model_dump(), feedback.feedback
    )
    tip, _ = generate_tip(profile.goal)

    revision = Plan(
        user_id=user.id,
        version=_next_version(db, user.id),
        parent_plan_id=parent.id,
        kind=PlanKind.REVISION,
        feedback_text=feedback.feedback,
        content=plan_content.model_dump(),
        profile_snapshot=_snapshot(profile),
        tip=tip,
        model_name=model_name,
        prompt_version=PROMPT_VERSION,
    )
    db.add(revision)
    db.commit()
    db.refresh(revision)

    logger.info(
        "plan_revised plan_id=%s parent_id=%s user_id=%s version=%s",
        revision.id,
        parent.id,
        user.id,
        revision.version,
    )
    return revision


def get_plan(db: Session, plan_id: int) -> Plan:
    plan = db.get(Plan, plan_id)
    if plan is None:
        raise NotFoundError("That plan does not exist.")
    return plan


def list_plans_for_user(db: Session, user_id: int) -> list[Plan]:
    """All of a user's plans, newest version first."""
    return list(
        db.scalars(select(Plan).where(Plan.user_id == user_id).order_by(Plan.version.desc()))
    )


def latest_plan(db: Session, user_id: int) -> Plan | None:
    return db.scalar(
        select(Plan).where(Plan.user_id == user_id).order_by(Plan.version.desc()).limit(1)
    )


def plan_chain(db: Session, plan: Plan) -> list[Plan]:
    """Walk from ``plan`` back to its original, then return the chain root-first.

    Used by the admin dashboard to show "original vs revised" side by side. The
    depth cap means corrupt data produces a truncated chain rather than an
    infinite loop.
    """
    chain: list[Plan] = [plan]
    seen = {plan.id}
    cursor: Plan | None = plan

    while (
        cursor is not None and cursor.parent_plan_id is not None and len(chain) < MAX_REVISION_DEPTH
    ):
        parent = db.get(Plan, cursor.parent_plan_id)
        if parent is None or parent.id in seen:
            logger.warning("plan_chain_broken plan_id=%s", plan.id)
            break
        chain.append(parent)
        seen.add(parent.id)
        cursor = parent

    chain.reverse()
    return chain


def chain_root(db: Session, plan: Plan) -> Plan:
    """The original plan this one descends from."""
    return plan_chain(db, plan)[0]
