"""Generation limits that protect the free API quota.

Two different limits, deliberately implemented differently:

* **Per-minute burst limit** - in-process sliding window. It exists to stop a
  user hammering the endpoint in a loop, and losing it on restart is harmless.
* **Daily quota** - counted from the ``plans`` table, not from memory. This one
  must survive a restart, otherwise restarting the app would hand everyone a
  fresh allowance of paid API calls.

Both are single-process by design. FitBuddy runs as one Uvicorn worker (ADR
007), so no shared store is needed. Moving to multiple workers means moving the
burst window to Redis; the daily quota already works unchanged, because it
lives in the database.
"""

from __future__ import annotations

import threading
import time
from collections import defaultdict, deque
from datetime import UTC, datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.enums import PlanKind
from app.errors import RateLimitError
from app.models import Plan


class SlidingWindowLimiter:
    """A thread-safe rolling-window counter keyed by an arbitrary string."""

    def __init__(self, limit: int, window_sec: int = 60) -> None:
        self.limit = limit
        self.window_sec = window_sec
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def check(self, key: str) -> None:
        """Record a hit for ``key`` or raise :class:`RateLimitError`."""
        now = time.monotonic()
        with self._lock:
            bucket = self._hits[key]
            cutoff = now - self.window_sec
            while bucket and bucket[0] <= cutoff:
                bucket.popleft()

            if len(bucket) >= self.limit:
                retry_after = max(1, int(bucket[0] + self.window_sec - now) + 1)
                raise RateLimitError(
                    f"You're going a little fast. Try again in about {retry_after} seconds.",
                    retry_after_sec=retry_after,
                )
            bucket.append(now)

            if len(self._hits) > 5_000:
                self._evict_empty()

    def _evict_empty(self) -> None:
        """Drop buckets with no live hits so memory cannot grow without bound."""
        cutoff = time.monotonic() - self.window_sec
        for key in [k for k, v in self._hits.items() if not v or v[-1] <= cutoff]:
            del self._hits[key]

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


#: Process-wide burst limiter for AI-backed operations.
burst_limiter = SlidingWindowLimiter(
    limit=get_settings().rate_limit_per_min,
    window_sec=60,
)


def check_generation_quota(db: Session, user_id: int) -> None:
    """Enforce the daily plan-generation quota for one user.

    Counted from stored plans so the limit holds across restarts. Revisions do
    not count: the quota exists to bound *new* generation cost, and a user
    refining an existing plan is the behaviour we are trying to encourage.
    """
    settings = get_settings()
    today_start = datetime.now(UTC).replace(hour=0, minute=0, second=0, microsecond=0)
    if today_start.tzinfo is None:  # pragma: no cover - defensive
        today_start = today_start.replace(tzinfo=UTC)

    used = db.scalar(
        select(func.count())
        .select_from(Plan)
        .where(
            Plan.user_id == user_id,
            Plan.kind == PlanKind.ORIGINAL,
            Plan.created_at >= today_start,
        )
    )
    used = used or 0

    if used >= settings.daily_generation_quota:
        raise RateLimitError(
            f"You've used today's {settings.daily_generation_quota} plans. "
            "Come back tomorrow, or refine an existing plan - that doesn't count.",
            retry_after_sec=_seconds_until_midnight(),
        )


def remaining_generations(db: Session, user_id: int) -> int:
    """How many new plans the user may still create today."""
    settings = get_settings()
    today_start = datetime.now(UTC).replace(hour=0, minute=0, second=0, microsecond=0)
    if today_start.tzinfo is None:  # pragma: no cover - defensive
        today_start = today_start.replace(tzinfo=UTC)

    used = db.scalar(
        select(func.count())
        .select_from(Plan)
        .where(
            Plan.user_id == user_id,
            Plan.kind == PlanKind.ORIGINAL,
            Plan.created_at >= today_start,
        )
    )
    return max(0, settings.daily_generation_quota - (used or 0))


def _seconds_until_midnight() -> int:
    now = datetime.now(UTC)
    tomorrow = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    return max(60, int((tomorrow - now).total_seconds()))


def enforce_generation_limits(db: Session, user_id: int) -> None:
    """Apply both limits. The burst check runs first because it is cheaper."""
    burst_limiter.check(f"gen:{user_id}")
    check_generation_quota(db, user_id)


def reset_limiters() -> None:
    """Clear in-process state. Test-only."""
    burst_limiter.reset()
