"""Business logic for accounts: registration, login, profile updates, deletion."""

from __future__ import annotations

import logging

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.enums import Role
from app.errors import AuthenticationError, ConflictError, NotFoundError
from app.models import Plan, User
from app.schemas import ProfileInput, RegisterInput
from app.security import find_user_by_email, hash_password, needs_rehash, verify_password

logger = logging.getLogger(__name__)


def register_user(db: Session, data: RegisterInput) -> User:
    """Create an account.

    New accounts are always ``Role.USER``. The role is set here, on the server,
    and ``RegisterInput`` forbids extra fields, so a posted ``role`` cannot
    reach this function.
    """
    if find_user_by_email(db, data.email) is not None:
        raise ConflictError("An account with that email already exists.", field="email")

    user = User(
        email=data.email,
        password_hash=hash_password(data.password),
        display_name=data.display_name,
        role=Role.USER,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    logger.info("user_registered user_id=%s", user.id)
    return user


def authenticate(db: Session, email: str, password: str) -> User:
    """Verify credentials.

    Raises 401 with a deliberately vague message: telling an attacker whether
    an email exists would leak account information.
    """
    user = find_user_by_email(db, email)
    if user is None:
        # Hash anyway so a missing account and a wrong password take the same time.
        verify_password(password, "")
        raise AuthenticationError("Email or password is incorrect.")

    if not verify_password(password, user.password_hash):
        raise AuthenticationError("Email or password is incorrect.")

    # Opportunistic upgrade if the hashing parameters have changed.
    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(password)
        db.commit()

    return user


def apply_profile(user: User, profile: ProfileInput, db: Session) -> User:
    """Copy validated profile values onto a user and persist them."""
    user.display_name = profile.display_name
    user.age = profile.age
    user.weight_kg = profile.weight_kg
    user.goal = profile.goal
    user.intensity = profile.intensity
    db.commit()
    db.refresh(user)
    return user


def get_user(db: Session, user_id: int) -> User:
    user = db.get(User, user_id)
    if user is None:
        raise NotFoundError("That account no longer exists.")
    return user


def delete_user(db: Session, user_id: int) -> None:
    """Delete an account and, by cascade, all of its plans."""
    user = db.get(User, user_id)
    if user is None:
        raise NotFoundError("That account no longer exists.")
    db.delete(user)
    db.commit()
    logger.info("user_deleted user_id=%s")


def list_users_paginated(
    db: Session, *, query: str = "", page: int = 1, page_size: int = 20
) -> tuple[list[tuple[User, int, Plan | None]], int]:
    """One page of users for the coach dashboard, newest first.

    Returns ``(rows, total)`` where each row is ``(user, plan_count, latest_plan)``.

    Search is a case-insensitive match on name or email. The subquery for the
    plan count and latest plan is done in SQL rather than in Python so the page
    size bounds the work regardless of how much data exists.
    """
    page = max(1, page)
    page_size = max(1, min(page_size, 100))

    conditions = []
    if query:
        pattern = f"%{query.strip()}%"
        conditions.append(or_(User.email.ilike(pattern), User.display_name.ilike(pattern)))

    total = db.scalar(select(func.count()).select_from(User).where(*conditions)) or 0

    plan_count_sq = (
        select(func.count(Plan.id)).where(Plan.user_id == User.id).correlate(User).scalar_subquery()
    )
    latest_version_sq = (
        select(func.max(Plan.version))
        .where(Plan.user_id == User.id)
        .correlate(User)
        .scalar_subquery()
    )

    rows = db.execute(
        select(User, plan_count_sq.label("plan_count"), latest_version_sq.label("latest_version"))
        .where(*conditions)
        .order_by(User.created_at.desc(), User.id.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    ).all()

    # Load the latest plan per user in one extra query instead of N.
    user_ids = [user.id for user, _, _ in rows]
    latest_plans: dict[int, Plan] = {}
    if user_ids:
        for plan in db.scalars(
            select(Plan)
            .where(Plan.user_id.in_(user_ids))
            .order_by(Plan.user_id, Plan.version.desc())
        ):
            latest_plans.setdefault(plan.user_id, plan)

    return (
        [(user, count, latest_plans.get(user.id)) for user, count, _ in rows],
        total,
    )
