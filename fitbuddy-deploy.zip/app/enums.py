"""Closed vocabularies shared by the ORM, the API schemas and the UI.

Goal and intensity are *fixed enumerations* rather than free text. That is a
security control as much as a UX one: it keeps unvalidated user text out of the
prompt (spec finding S3) and gives the model a small, unambiguous input space.
"""

from __future__ import annotations

from enum import StrEnum


class Role(StrEnum):
    """Who a user is allowed to be."""

    USER = "user"
    ADMIN = "admin"

    @property
    def label(self) -> str:
        return "Coach / Admin" if self is Role.ADMIN else "Member"


class Goal(StrEnum):
    """Training objective."""

    WEIGHT_LOSS = "weight_loss"
    MUSCLE_GAIN = "muscle_gain"
    ENDURANCE = "endurance"
    GENERAL_FITNESS = "general_fitness"
    FLEXIBILITY = "flexibility"

    @property
    def label(self) -> str:
        return {
            Goal.WEIGHT_LOSS: "Weight loss",
            Goal.MUSCLE_GAIN: "Muscle gain",
            Goal.ENDURANCE: "Endurance & stamina",
            Goal.GENERAL_FITNESS: "General fitness",
            Goal.FLEXIBILITY: "Flexibility & mobility",
        }[self]

    @property
    def description(self) -> str:
        return {
            Goal.WEIGHT_LOSS: "Lose fat while keeping muscle",
            Goal.MUSCLE_GAIN: "Build strength and lean muscle",
            Goal.ENDURANCE: "Improve cardiovascular stamina",
            Goal.GENERAL_FITNESS: "Stay healthy and fit all round",
            Goal.FLEXIBILITY: "Move better, loosen up, reduce stiffness",
        }[self]


class Intensity(StrEnum):
    """How hard the week should feel."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

    @property
    def label(self) -> str:
        return {Intensity.LOW: "Low", Intensity.MEDIUM: "Medium", Intensity.HIGH: "High"}[self]

    @property
    def description(self) -> str:
        return {
            Intensity.LOW: "Gentle start, plenty of recovery",
            Intensity.MEDIUM: "Moderate effort, 2 rest days",
            Intensity.HIGH: "Challenging, 1 rest day minimum",
        }[self]


class PlanKind(StrEnum):
    """Whether a plan row starts a chain or continues one."""

    ORIGINAL = "original"
    REVISION = "revision"

    @property
    def label(self) -> str:
        return "Original" if self is PlanKind.ORIGINAL else "Revision"


#: Ordered choices for rendering `<select>` elements.
GOAL_CHOICES: tuple[Goal, ...] = tuple(Goal)
INTENSITY_CHOICES: tuple[Intensity, ...] = tuple(Intensity)
